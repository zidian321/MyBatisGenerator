package com.ibm.dk.alr.zscm.scrt.storing.mybatis.data;

import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.WLMREP;
import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.WLMREPKey;

public interface WLMREPMapper {
    int deleteByPrimaryKey(WLMREPKey key);

    int insert(WLMREP record);

    int insertSelective(WLMREP record);

    WLMREP selectByPrimaryKey(WLMREPKey key);

    int updateByPrimaryKeySelective(WLMREP record);

    int updateByPrimaryKey(WLMREP record);
}