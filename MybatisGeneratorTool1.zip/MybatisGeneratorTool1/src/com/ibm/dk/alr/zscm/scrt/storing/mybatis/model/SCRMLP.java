package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

import java.util.Date;

public class SCRMLP {
    private String isubrid;

    private Integer isubrep;

    private String imlpsec;

    private Integer imlpseq;

    private String imlpco1;

    private String imlpco2;

    private String imlpco3;

    private String imlpco4;

    private Date dmlpaut;

    private String smlpauu;

    private String smlpaup;

    private Integer qmlpmhr;

    private String qmlpepu;

    public String getIsubrid() {
        return isubrid;
    }

    public void setIsubrid(String isubrid) {
        this.isubrid = isubrid == null ? null : isubrid.trim();
    }

    public Integer getIsubrep() {
        return isubrep;
    }

    public void setIsubrep(Integer isubrep) {
        this.isubrep = isubrep;
    }

    public String getImlpsec() {
        return imlpsec;
    }

    public void setImlpsec(String imlpsec) {
        this.imlpsec = imlpsec == null ? null : imlpsec.trim();
    }

    public Integer getImlpseq() {
        return imlpseq;
    }

    public void setImlpseq(Integer imlpseq) {
        this.imlpseq = imlpseq;
    }

    public String getImlpco1() {
        return imlpco1;
    }

    public void setImlpco1(String imlpco1) {
        this.imlpco1 = imlpco1 == null ? null : imlpco1.trim();
    }

    public String getImlpco2() {
        return imlpco2;
    }

    public void setImlpco2(String imlpco2) {
        this.imlpco2 = imlpco2 == null ? null : imlpco2.trim();
    }

    public String getImlpco3() {
        return imlpco3;
    }

    public void setImlpco3(String imlpco3) {
        this.imlpco3 = imlpco3 == null ? null : imlpco3.trim();
    }

    public String getImlpco4() {
        return imlpco4;
    }

    public void setImlpco4(String imlpco4) {
        this.imlpco4 = imlpco4 == null ? null : imlpco4.trim();
    }

    public Date getDmlpaut() {
        return dmlpaut;
    }

    public void setDmlpaut(Date dmlpaut) {
        this.dmlpaut = dmlpaut;
    }

    public String getSmlpauu() {
        return smlpauu;
    }

    public void setSmlpauu(String smlpauu) {
        this.smlpauu = smlpauu == null ? null : smlpauu.trim();
    }

    public String getSmlpaup() {
        return smlpaup;
    }

    public void setSmlpaup(String smlpaup) {
        this.smlpaup = smlpaup == null ? null : smlpaup.trim();
    }

    public Integer getQmlpmhr() {
        return qmlpmhr;
    }

    public void setQmlpmhr(Integer qmlpmhr) {
        this.qmlpmhr = qmlpmhr;
    }

    public String getQmlpepu() {
        return qmlpepu;
    }

    public void setQmlpepu(String qmlpepu) {
        this.qmlpepu = qmlpepu == null ? null : qmlpepu.trim();
    }
}