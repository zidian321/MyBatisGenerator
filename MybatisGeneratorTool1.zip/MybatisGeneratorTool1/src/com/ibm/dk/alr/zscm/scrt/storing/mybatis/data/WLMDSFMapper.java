package com.ibm.dk.alr.zscm.scrt.storing.mybatis.data;

import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.WLMDSF;

public interface WLMDSFMapper {
    int insert(WLMDSF record);

    int insertSelective(WLMDSF record);
}