package com.ibm.dk.alr.zscm.scrt.storing.mybatis.data;

import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.WLMMCN;
import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.WLMMCNKey;

public interface WLMMCNMapper {
    int deleteByPrimaryKey(WLMMCNKey key);

    int insert(WLMMCN record);

    int insertSelective(WLMMCN record);

    WLMMCN selectByPrimaryKey(WLMMCNKey key);

    int updateByPrimaryKeySelective(WLMMCN record);

    int updateByPrimaryKey(WLMMCN record);
}