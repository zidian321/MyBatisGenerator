package com.ibm.dk.alr.zscm.scrt.storing.mybatis.data;

import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.SCRMOP;
import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.SCRMOPKey;

public interface SCRMOPMapper {
    int deleteByPrimaryKey(SCRMOPKey key);

    int insert(SCRMOP record);

    int insertSelective(SCRMOP record);

    SCRMOP selectByPrimaryKey(SCRMOPKey key);

    int updateByPrimaryKeySelective(SCRMOP record);

    int updateByPrimaryKey(SCRMOP record);
}