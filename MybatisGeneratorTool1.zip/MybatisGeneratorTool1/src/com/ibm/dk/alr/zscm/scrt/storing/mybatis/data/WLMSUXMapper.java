package com.ibm.dk.alr.zscm.scrt.storing.mybatis.data;

import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.WLMSUX;

public interface WLMSUXMapper {
    int deleteByPrimaryKey(String isubrid);

    int insert(WLMSUX record);

    int insertSelective(WLMSUX record);

    WLMSUX selectByPrimaryKey(String isubrid);

    int updateByPrimaryKeySelective(WLMSUX record);

    int updateByPrimaryKey(WLMSUX record);
}