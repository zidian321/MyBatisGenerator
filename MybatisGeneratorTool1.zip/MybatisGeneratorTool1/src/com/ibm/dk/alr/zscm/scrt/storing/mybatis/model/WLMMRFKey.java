package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

public class WLMMRFKey {
    private String isubmid;

    private Integer isubrep;

    private String cmrftyp;

    private Integer imrfrow;

    public String getIsubmid() {
        return isubmid;
    }

    public void setIsubmid(String isubmid) {
        this.isubmid = isubmid == null ? null : isubmid.trim();
    }

    public Integer getIsubrep() {
        return isubrep;
    }

    public void setIsubrep(Integer isubrep) {
        this.isubrep = isubrep;
    }

    public String getCmrftyp() {
        return cmrftyp;
    }

    public void setCmrftyp(String cmrftyp) {
        this.cmrftyp = cmrftyp == null ? null : cmrftyp.trim();
    }

    public Integer getImrfrow() {
        return imrfrow;
    }

    public void setImrfrow(Integer imrfrow) {
        this.imrfrow = imrfrow;
    }
}