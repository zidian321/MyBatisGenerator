package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

import java.util.Date;

public class WLMCPM extends WLMCPMKey {
    private String dperper;

    private String ipgmnbr;

    private String ncpmcpn;

    private String nprdnbr;

    private Integer qcpmpru;

    private String tcpmprm;

    private Date dcpmaut;

    private String scpmaup;

    private String scpmauu;

    public String getDperper() {
        return dperper;
    }

    public void setDperper(String dperper) {
        this.dperper = dperper == null ? null : dperper.trim();
    }

    public String getIpgmnbr() {
        return ipgmnbr;
    }

    public void setIpgmnbr(String ipgmnbr) {
        this.ipgmnbr = ipgmnbr == null ? null : ipgmnbr.trim();
    }

    public String getNcpmcpn() {
        return ncpmcpn;
    }

    public void setNcpmcpn(String ncpmcpn) {
        this.ncpmcpn = ncpmcpn == null ? null : ncpmcpn.trim();
    }

    public String getNprdnbr() {
        return nprdnbr;
    }

    public void setNprdnbr(String nprdnbr) {
        this.nprdnbr = nprdnbr == null ? null : nprdnbr.trim();
    }

    public Integer getQcpmpru() {
        return qcpmpru;
    }

    public void setQcpmpru(Integer qcpmpru) {
        this.qcpmpru = qcpmpru;
    }

    public String getTcpmprm() {
        return tcpmprm;
    }

    public void setTcpmprm(String tcpmprm) {
        this.tcpmprm = tcpmprm == null ? null : tcpmprm.trim();
    }

    public Date getDcpmaut() {
        return dcpmaut;
    }

    public void setDcpmaut(Date dcpmaut) {
        this.dcpmaut = dcpmaut;
    }

    public String getScpmaup() {
        return scpmaup;
    }

    public void setScpmaup(String scpmaup) {
        this.scpmaup = scpmaup == null ? null : scpmaup.trim();
    }

    public String getScpmauu() {
        return scpmauu;
    }

    public void setScpmauu(String scpmauu) {
        this.scpmauu = scpmauu == null ? null : scpmauu.trim();
    }
}