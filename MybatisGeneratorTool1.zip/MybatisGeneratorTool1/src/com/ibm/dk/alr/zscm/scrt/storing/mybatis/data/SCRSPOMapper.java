package com.ibm.dk.alr.zscm.scrt.storing.mybatis.data;

import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.SCRSPO;

public interface SCRSPOMapper {
    int deleteByPrimaryKey(Integer sspospi);

    int insert(SCRSPO record);

    int insertSelective(SCRSPO record);

    SCRSPO selectByPrimaryKey(Integer sspospi);

    int updateByPrimaryKeySelective(SCRSPO record);

    int updateByPrimaryKey(SCRSPO record);
}