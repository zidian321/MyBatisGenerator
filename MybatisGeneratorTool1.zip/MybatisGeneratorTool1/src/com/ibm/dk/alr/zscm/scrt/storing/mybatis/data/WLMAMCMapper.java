package com.ibm.dk.alr.zscm.scrt.storing.mybatis.data;

import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.WLMAMC;

public interface WLMAMCMapper {
    int insert(WLMAMC record);

    int insertSelective(WLMAMC record);
}