package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

import java.util.Date;

public class SCRSPL {
    private String isubrid;

    private String fsubste;

    private Date dspltms;

    private String isplcom;

    private String csplcas;

    private String tsplrea;

    private String tspldlo;

    private String tsplusr;

    private String dperper;

    private Date dsplaut;

    private String ssplauu;

    private String ssplaup;

    private Integer isubrep;

    public String getIsubrid() {
        return isubrid;
    }

    public void setIsubrid(String isubrid) {
        this.isubrid = isubrid == null ? null : isubrid.trim();
    }

    public String getFsubste() {
        return fsubste;
    }

    public void setFsubste(String fsubste) {
        this.fsubste = fsubste == null ? null : fsubste.trim();
    }

    public Date getDspltms() {
        return dspltms;
    }

    public void setDspltms(Date dspltms) {
        this.dspltms = dspltms;
    }

    public String getIsplcom() {
        return isplcom;
    }

    public void setIsplcom(String isplcom) {
        this.isplcom = isplcom == null ? null : isplcom.trim();
    }

    public String getCsplcas() {
        return csplcas;
    }

    public void setCsplcas(String csplcas) {
        this.csplcas = csplcas == null ? null : csplcas.trim();
    }

    public String getTsplrea() {
        return tsplrea;
    }

    public void setTsplrea(String tsplrea) {
        this.tsplrea = tsplrea == null ? null : tsplrea.trim();
    }

    public String getTspldlo() {
        return tspldlo;
    }

    public void setTspldlo(String tspldlo) {
        this.tspldlo = tspldlo == null ? null : tspldlo.trim();
    }

    public String getTsplusr() {
        return tsplusr;
    }

    public void setTsplusr(String tsplusr) {
        this.tsplusr = tsplusr == null ? null : tsplusr.trim();
    }

    public String getDperper() {
        return dperper;
    }

    public void setDperper(String dperper) {
        this.dperper = dperper == null ? null : dperper.trim();
    }

    public Date getDsplaut() {
        return dsplaut;
    }

    public void setDsplaut(Date dsplaut) {
        this.dsplaut = dsplaut;
    }

    public String getSsplauu() {
        return ssplauu;
    }

    public void setSsplauu(String ssplauu) {
        this.ssplauu = ssplauu == null ? null : ssplauu.trim();
    }

    public String getSsplaup() {
        return ssplaup;
    }

    public void setSsplaup(String ssplaup) {
        this.ssplaup = ssplaup == null ? null : ssplaup.trim();
    }

    public Integer getIsubrep() {
        return isubrep;
    }

    public void setIsubrep(Integer isubrep) {
        this.isubrep = isubrep;
    }
}