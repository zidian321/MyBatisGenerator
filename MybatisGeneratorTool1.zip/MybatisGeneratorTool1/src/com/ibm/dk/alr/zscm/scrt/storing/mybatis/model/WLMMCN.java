package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

import java.util.Date;

public class WLMMCN extends WLMMCNKey {
    private String fmcnmas;

    private Date dmcnaut;

    private String smcnauu;

    private String smcnaup;

    public String getFmcnmas() {
        return fmcnmas;
    }

    public void setFmcnmas(String fmcnmas) {
        this.fmcnmas = fmcnmas == null ? null : fmcnmas.trim();
    }

    public Date getDmcnaut() {
        return dmcnaut;
    }

    public void setDmcnaut(Date dmcnaut) {
        this.dmcnaut = dmcnaut;
    }

    public String getSmcnauu() {
        return smcnauu;
    }

    public void setSmcnauu(String smcnauu) {
        this.smcnauu = smcnauu == null ? null : smcnauu.trim();
    }

    public String getSmcnaup() {
        return smcnaup;
    }

    public void setSmcnaup(String smcnaup) {
        this.smcnaup = smcnaup == null ? null : smcnaup.trim();
    }
}