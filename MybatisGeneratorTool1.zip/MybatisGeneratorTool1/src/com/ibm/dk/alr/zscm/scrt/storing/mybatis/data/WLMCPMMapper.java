package com.ibm.dk.alr.zscm.scrt.storing.mybatis.data;

import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.WLMCPM;
import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.WLMCPMKey;

public interface WLMCPMMapper {
    int deleteByPrimaryKey(WLMCPMKey key);

    int insert(WLMCPM record);

    int insertSelective(WLMCPM record);

    WLMCPM selectByPrimaryKey(WLMCPMKey key);

    int updateByPrimaryKeySelective(WLMCPM record);

    int updateByPrimaryKey(WLMCPM record);
}