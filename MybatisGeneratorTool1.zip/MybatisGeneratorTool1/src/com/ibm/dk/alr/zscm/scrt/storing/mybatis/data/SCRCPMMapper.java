package com.ibm.dk.alr.zscm.scrt.storing.mybatis.data;

import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.SCRCPM;
import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.SCRCPMKey;

public interface SCRCPMMapper {
    int deleteByPrimaryKey(SCRCPMKey key);

    int insert(SCRCPM record);

    int insertSelective(SCRCPM record);

    SCRCPM selectByPrimaryKey(SCRCPMKey key);

    int updateByPrimaryKeySelective(SCRCPM record);

    int updateByPrimaryKey(SCRCPM record);
}