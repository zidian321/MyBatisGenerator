package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

public class WLMDSUKey {
    private String idsurid;

    private String fdsuste;

    public String getIdsurid() {
        return idsurid;
    }

    public void setIdsurid(String idsurid) {
        this.idsurid = idsurid == null ? null : idsurid.trim();
    }

    public String getFdsuste() {
        return fdsuste;
    }

    public void setFdsuste(String fdsuste) {
        this.fdsuste = fdsuste == null ? null : fdsuste.trim();
    }
}