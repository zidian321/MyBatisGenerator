package com.ibm.dk.alr.zscm.scrt.storing.mybatis.data;

import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.WLMDCS;
import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.WLMDCSExample;

public interface WLMDCSMapper {
    long countByExample(WLMDCSExample example);

    int insert(WLMDCS record);

    int insertSelective(WLMDCS record);
}