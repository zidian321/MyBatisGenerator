package com.ibm.dk.alr.zscm.scrt.storing.mybatis.data;

import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.WLMACU;
import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.WLMACUKey;

public interface WLMACUMapper {
    int deleteByPrimaryKey(WLMACUKey key);

    int insert(WLMACU record);

    int insertSelective(WLMACU record);

    WLMACU selectByPrimaryKey(WLMACUKey key);

    int updateByPrimaryKeySelective(WLMACU record);

    int updateByPrimaryKey(WLMACU record);
}