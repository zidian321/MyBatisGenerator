package com.ibm.dk.alr.zscm.scrt.storing.mybatis.data;

import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.SCRSUX;
import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.SCRSUXKey;

public interface SCRSUXMapper {
    int deleteByPrimaryKey(SCRSUXKey key);

    int insert(SCRSUX record);

    int insertSelective(SCRSUX record);

    SCRSUX selectByPrimaryKey(SCRSUXKey key);

    int updateByPrimaryKeySelective(SCRSUX record);

    int updateByPrimaryKey(SCRSUX record);
}