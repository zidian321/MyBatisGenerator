package com.ibm.dk.alr.zscm.scrt.storing.mybatis.data;

import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.SCRACU;
import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.SCRACUKey;

public interface SCRACUMapper {
    int deleteByPrimaryKey(SCRACUKey key);

    int insert(SCRACU record);

    int insertSelective(SCRACU record);

    SCRACU selectByPrimaryKey(SCRACUKey key);

    int updateByPrimaryKeySelective(SCRACU record);

    int updateByPrimaryKey(SCRACU record);
}