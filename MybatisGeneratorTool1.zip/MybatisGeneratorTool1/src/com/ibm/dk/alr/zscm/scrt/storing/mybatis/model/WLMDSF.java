package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

import java.util.Date;

public class WLMDSF {
    private String idsurid;

    private String ldsffle;

    private Integer qdsfrow;

    private Date ddsfaut;

    private String ndsfauu;

    private String ndsfaup;

    private String fdsuste;

    public String getIdsurid() {
        return idsurid;
    }

    public void setIdsurid(String idsurid) {
        this.idsurid = idsurid == null ? null : idsurid.trim();
    }

    public String getLdsffle() {
        return ldsffle;
    }

    public void setLdsffle(String ldsffle) {
        this.ldsffle = ldsffle == null ? null : ldsffle.trim();
    }

    public Integer getQdsfrow() {
        return qdsfrow;
    }

    public void setQdsfrow(Integer qdsfrow) {
        this.qdsfrow = qdsfrow;
    }

    public Date getDdsfaut() {
        return ddsfaut;
    }

    public void setDdsfaut(Date ddsfaut) {
        this.ddsfaut = ddsfaut;
    }

    public String getNdsfauu() {
        return ndsfauu;
    }

    public void setNdsfauu(String ndsfauu) {
        this.ndsfauu = ndsfauu == null ? null : ndsfauu.trim();
    }

    public String getNdsfaup() {
        return ndsfaup;
    }

    public void setNdsfaup(String ndsfaup) {
        this.ndsfaup = ndsfaup == null ? null : ndsfaup.trim();
    }

    public String getFdsuste() {
        return fdsuste;
    }

    public void setFdsuste(String fdsuste) {
        this.fdsuste = fdsuste == null ? null : fdsuste.trim();
    }
}