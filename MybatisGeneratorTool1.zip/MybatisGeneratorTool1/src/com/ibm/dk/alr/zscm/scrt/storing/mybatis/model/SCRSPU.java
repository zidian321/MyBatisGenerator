package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

import java.util.Date;

public class SCRSPU {
    private Integer sspuspi;

    private Integer ispuseq;

    private String ispuco1;

    private String ispuco2;

    private String ispuco3;

    private String ispuco4;

    private String ispuco5;

    private String ispuco6;

    private String isubrid;

    private Integer sspssid;

    private Date dspuaut;

    private String nspuauu;

    private String nspuaup;

    private String ispuco7;

    private String ispuco8;

    private Integer isubrep;

    public Integer getSspuspi() {
        return sspuspi;
    }

    public void setSspuspi(Integer sspuspi) {
        this.sspuspi = sspuspi;
    }

    public Integer getIspuseq() {
        return ispuseq;
    }

    public void setIspuseq(Integer ispuseq) {
        this.ispuseq = ispuseq;
    }

    public String getIspuco1() {
        return ispuco1;
    }

    public void setIspuco1(String ispuco1) {
        this.ispuco1 = ispuco1 == null ? null : ispuco1.trim();
    }

    public String getIspuco2() {
        return ispuco2;
    }

    public void setIspuco2(String ispuco2) {
        this.ispuco2 = ispuco2 == null ? null : ispuco2.trim();
    }

    public String getIspuco3() {
        return ispuco3;
    }

    public void setIspuco3(String ispuco3) {
        this.ispuco3 = ispuco3 == null ? null : ispuco3.trim();
    }

    public String getIspuco4() {
        return ispuco4;
    }

    public void setIspuco4(String ispuco4) {
        this.ispuco4 = ispuco4 == null ? null : ispuco4.trim();
    }

    public String getIspuco5() {
        return ispuco5;
    }

    public void setIspuco5(String ispuco5) {
        this.ispuco5 = ispuco5 == null ? null : ispuco5.trim();
    }

    public String getIspuco6() {
        return ispuco6;
    }

    public void setIspuco6(String ispuco6) {
        this.ispuco6 = ispuco6 == null ? null : ispuco6.trim();
    }

    public String getIsubrid() {
        return isubrid;
    }

    public void setIsubrid(String isubrid) {
        this.isubrid = isubrid == null ? null : isubrid.trim();
    }

    public Integer getSspssid() {
        return sspssid;
    }

    public void setSspssid(Integer sspssid) {
        this.sspssid = sspssid;
    }

    public Date getDspuaut() {
        return dspuaut;
    }

    public void setDspuaut(Date dspuaut) {
        this.dspuaut = dspuaut;
    }

    public String getNspuauu() {
        return nspuauu;
    }

    public void setNspuauu(String nspuauu) {
        this.nspuauu = nspuauu == null ? null : nspuauu.trim();
    }

    public String getNspuaup() {
        return nspuaup;
    }

    public void setNspuaup(String nspuaup) {
        this.nspuaup = nspuaup == null ? null : nspuaup.trim();
    }

    public String getIspuco7() {
        return ispuco7;
    }

    public void setIspuco7(String ispuco7) {
        this.ispuco7 = ispuco7 == null ? null : ispuco7.trim();
    }

    public String getIspuco8() {
        return ispuco8;
    }

    public void setIspuco8(String ispuco8) {
        this.ispuco8 = ispuco8 == null ? null : ispuco8.trim();
    }

    public Integer getIsubrep() {
        return isubrep;
    }

    public void setIsubrep(Integer isubrep) {
        this.isubrep = isubrep;
    }
}