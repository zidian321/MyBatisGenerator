package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

import java.util.Date;

public class WLMDCS {
    private String idsurid;

    private String ldcsfle;

    private Integer qdcsrow;

    private Date ddcsaut;

    private String ndcsauu;

    private String ndcsaup;

    private String fdsuste;

    public String getIdsurid() {
        return idsurid;
    }

    public void setIdsurid(String idsurid) {
        this.idsurid = idsurid == null ? null : idsurid.trim();
    }

    public String getLdcsfle() {
        return ldcsfle;
    }

    public void setLdcsfle(String ldcsfle) {
        this.ldcsfle = ldcsfle == null ? null : ldcsfle.trim();
    }

    public Integer getQdcsrow() {
        return qdcsrow;
    }

    public void setQdcsrow(Integer qdcsrow) {
        this.qdcsrow = qdcsrow;
    }

    public Date getDdcsaut() {
        return ddcsaut;
    }

    public void setDdcsaut(Date ddcsaut) {
        this.ddcsaut = ddcsaut;
    }

    public String getNdcsauu() {
        return ndcsauu;
    }

    public void setNdcsauu(String ndcsauu) {
        this.ndcsauu = ndcsauu == null ? null : ndcsauu.trim();
    }

    public String getNdcsaup() {
        return ndcsaup;
    }

    public void setNdcsaup(String ndcsaup) {
        this.ndcsaup = ndcsaup == null ? null : ndcsaup.trim();
    }

    public String getFdsuste() {
        return fdsuste;
    }

    public void setFdsuste(String fdsuste) {
        this.fdsuste = fdsuste == null ? null : fdsuste.trim();
    }
}