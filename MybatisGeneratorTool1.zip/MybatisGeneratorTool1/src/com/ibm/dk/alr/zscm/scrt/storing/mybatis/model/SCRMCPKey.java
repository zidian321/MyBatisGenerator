package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

public class SCRMCPKey {
    private String isubmid;

    private Integer imimseq;

    private String imcpcid;

    public String getIsubmid() {
        return isubmid;
    }

    public void setIsubmid(String isubmid) {
        this.isubmid = isubmid == null ? null : isubmid.trim();
    }

    public Integer getImimseq() {
        return imimseq;
    }

    public void setImimseq(Integer imimseq) {
        this.imimseq = imimseq;
    }

    public String getImcpcid() {
        return imcpcid;
    }

    public void setImcpcid(String imcpcid) {
        this.imcpcid = imcpcid == null ? null : imcpcid.trim();
    }
}