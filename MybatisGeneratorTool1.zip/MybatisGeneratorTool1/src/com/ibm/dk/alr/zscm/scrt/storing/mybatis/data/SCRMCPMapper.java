package com.ibm.dk.alr.zscm.scrt.storing.mybatis.data;

import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.SCRMCP;
import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.SCRMCPKey;

public interface SCRMCPMapper {
    int deleteByPrimaryKey(SCRMCPKey key);

    int insert(SCRMCP record);

    int insertSelective(SCRMCP record);

    SCRMCP selectByPrimaryKey(SCRMCPKey key);

    int updateByPrimaryKeySelective(SCRMCP record);

    int updateByPrimaryKey(SCRMCP record);
}