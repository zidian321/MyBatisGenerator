package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

import java.util.Date;

public class WLMHEX extends WLMHEXKey {
    private String ilgciso;

    private String ictyiso;

    private String iappapp;

    private String ittytty;

    private String ichschs;

    private String chextxt;

    private String dhexaum;

    private Date dhexadm;

    public String getIlgciso() {
        return ilgciso;
    }

    public void setIlgciso(String ilgciso) {
        this.ilgciso = ilgciso == null ? null : ilgciso.trim();
    }

    public String getIctyiso() {
        return ictyiso;
    }

    public void setIctyiso(String ictyiso) {
        this.ictyiso = ictyiso == null ? null : ictyiso.trim();
    }

    public String getIappapp() {
        return iappapp;
    }

    public void setIappapp(String iappapp) {
        this.iappapp = iappapp == null ? null : iappapp.trim();
    }

    public String getIttytty() {
        return ittytty;
    }

    public void setIttytty(String ittytty) {
        this.ittytty = ittytty == null ? null : ittytty.trim();
    }

    public String getIchschs() {
        return ichschs;
    }

    public void setIchschs(String ichschs) {
        this.ichschs = ichschs == null ? null : ichschs.trim();
    }

    public String getChextxt() {
        return chextxt;
    }

    public void setChextxt(String chextxt) {
        this.chextxt = chextxt == null ? null : chextxt.trim();
    }

    public String getDhexaum() {
        return dhexaum;
    }

    public void setDhexaum(String dhexaum) {
        this.dhexaum = dhexaum == null ? null : dhexaum.trim();
    }

    public Date getDhexadm() {
        return dhexadm;
    }

    public void setDhexadm(Date dhexadm) {
        this.dhexadm = dhexadm;
    }
}