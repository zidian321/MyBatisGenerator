package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

public class WLMZMFKey {
    private String isubmid;

    private Integer isubrep;

    public String getIsubmid() {
        return isubmid;
    }

    public void setIsubmid(String isubmid) {
        this.isubmid = isubmid == null ? null : isubmid.trim();
    }

    public Integer getIsubrep() {
        return isubrep;
    }

    public void setIsubrep(Integer isubrep) {
        this.isubrep = isubrep;
    }
}