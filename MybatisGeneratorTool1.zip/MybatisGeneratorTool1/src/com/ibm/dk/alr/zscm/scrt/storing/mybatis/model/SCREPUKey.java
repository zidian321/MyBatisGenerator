package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

public class SCREPUKey {
    private String isubrid;

    private Integer isubrep;

    private String nepuopn;

    private String ipgmnbr;

    public String getIsubrid() {
        return isubrid;
    }

    public void setIsubrid(String isubrid) {
        this.isubrid = isubrid == null ? null : isubrid.trim();
    }

    public Integer getIsubrep() {
        return isubrep;
    }

    public void setIsubrep(Integer isubrep) {
        this.isubrep = isubrep;
    }

    public String getNepuopn() {
        return nepuopn;
    }

    public void setNepuopn(String nepuopn) {
        this.nepuopn = nepuopn == null ? null : nepuopn.trim();
    }

    public String getIpgmnbr() {
        return ipgmnbr;
    }

    public void setIpgmnbr(String ipgmnbr) {
        this.ipgmnbr = ipgmnbr == null ? null : ipgmnbr.trim();
    }
}