package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

import java.util.Date;

public class WLMAMC {
    private String iamcrmc;

    private String iamcamc;

    private String camcrem;

    private String camcjus;

    private Date damcaut;

    private String samcaup;

    private String samcauu;

    public String getIamcrmc() {
        return iamcrmc;
    }

    public void setIamcrmc(String iamcrmc) {
        this.iamcrmc = iamcrmc == null ? null : iamcrmc.trim();
    }

    public String getIamcamc() {
        return iamcamc;
    }

    public void setIamcamc(String iamcamc) {
        this.iamcamc = iamcamc == null ? null : iamcamc.trim();
    }

    public String getCamcrem() {
        return camcrem;
    }

    public void setCamcrem(String camcrem) {
        this.camcrem = camcrem == null ? null : camcrem.trim();
    }

    public String getCamcjus() {
        return camcjus;
    }

    public void setCamcjus(String camcjus) {
        this.camcjus = camcjus == null ? null : camcjus.trim();
    }

    public Date getDamcaut() {
        return damcaut;
    }

    public void setDamcaut(Date damcaut) {
        this.damcaut = damcaut;
    }

    public String getSamcaup() {
        return samcaup;
    }

    public void setSamcaup(String samcaup) {
        this.samcaup = samcaup == null ? null : samcaup.trim();
    }

    public String getSamcauu() {
        return samcauu;
    }

    public void setSamcauu(String samcauu) {
        this.samcauu = samcauu == null ? null : samcauu.trim();
    }
}