package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

import java.util.Date;

public class WLMZMF extends WLMZMFKey {
    private Date dzmfaut;

    private String szmfauu;

    private String szmfaup;

    private Object db2GeneratedRowidForLobs;

    private byte[] bzmffle;

    public Date getDzmfaut() {
        return dzmfaut;
    }

    public void setDzmfaut(Date dzmfaut) {
        this.dzmfaut = dzmfaut;
    }

    public String getSzmfauu() {
        return szmfauu;
    }

    public void setSzmfauu(String szmfauu) {
        this.szmfauu = szmfauu == null ? null : szmfauu.trim();
    }

    public String getSzmfaup() {
        return szmfaup;
    }

    public void setSzmfaup(String szmfaup) {
        this.szmfaup = szmfaup == null ? null : szmfaup.trim();
    }

    public Object getDb2GeneratedRowidForLobs() {
        return db2GeneratedRowidForLobs;
    }

    public void setDb2GeneratedRowidForLobs(Object db2GeneratedRowidForLobs) {
        this.db2GeneratedRowidForLobs = db2GeneratedRowidForLobs;
    }

    public byte[] getBzmffle() {
        return bzmffle;
    }

    public void setBzmffle(byte[] bzmffle) {
        this.bzmffle = bzmffle;
    }
}