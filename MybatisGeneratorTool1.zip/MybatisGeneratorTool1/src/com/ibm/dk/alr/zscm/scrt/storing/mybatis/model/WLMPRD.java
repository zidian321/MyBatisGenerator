package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

import java.util.Date;

public class WLMPRD {
    private String isubrid;

    private String fsubste;

    private String qprdtmu;

    private String qprdcmu;

    private String qprdccm;

    private String nprdnme;

    private String nprdnbr;

    private String cprdtpe;

    private Date dprdaut;

    private String nprdauu;

    private String nprdaup;

    private Integer isubrep;

    public String getIsubrid() {
        return isubrid;
    }

    public void setIsubrid(String isubrid) {
        this.isubrid = isubrid == null ? null : isubrid.trim();
    }

    public String getFsubste() {
        return fsubste;
    }

    public void setFsubste(String fsubste) {
        this.fsubste = fsubste == null ? null : fsubste.trim();
    }

    public String getQprdtmu() {
        return qprdtmu;
    }

    public void setQprdtmu(String qprdtmu) {
        this.qprdtmu = qprdtmu == null ? null : qprdtmu.trim();
    }

    public String getQprdcmu() {
        return qprdcmu;
    }

    public void setQprdcmu(String qprdcmu) {
        this.qprdcmu = qprdcmu == null ? null : qprdcmu.trim();
    }

    public String getQprdccm() {
        return qprdccm;
    }

    public void setQprdccm(String qprdccm) {
        this.qprdccm = qprdccm == null ? null : qprdccm.trim();
    }

    public String getNprdnme() {
        return nprdnme;
    }

    public void setNprdnme(String nprdnme) {
        this.nprdnme = nprdnme == null ? null : nprdnme.trim();
    }

    public String getNprdnbr() {
        return nprdnbr;
    }

    public void setNprdnbr(String nprdnbr) {
        this.nprdnbr = nprdnbr == null ? null : nprdnbr.trim();
    }

    public String getCprdtpe() {
        return cprdtpe;
    }

    public void setCprdtpe(String cprdtpe) {
        this.cprdtpe = cprdtpe == null ? null : cprdtpe.trim();
    }

    public Date getDprdaut() {
        return dprdaut;
    }

    public void setDprdaut(Date dprdaut) {
        this.dprdaut = dprdaut;
    }

    public String getNprdauu() {
        return nprdauu;
    }

    public void setNprdauu(String nprdauu) {
        this.nprdauu = nprdauu == null ? null : nprdauu.trim();
    }

    public String getNprdaup() {
        return nprdaup;
    }

    public void setNprdaup(String nprdaup) {
        this.nprdaup = nprdaup == null ? null : nprdaup.trim();
    }

    public Integer getIsubrep() {
        return isubrep;
    }

    public void setIsubrep(Integer isubrep) {
        this.isubrep = isubrep;
    }
}