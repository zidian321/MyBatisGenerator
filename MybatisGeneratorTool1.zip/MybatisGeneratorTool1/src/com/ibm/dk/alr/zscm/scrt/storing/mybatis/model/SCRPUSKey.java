package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

public class SCRPUSKey {
    private String isubrid;

    private Integer isubrep;

    private Integer ipusseq;

    private String ipgmnbr;

    public String getIsubrid() {
        return isubrid;
    }

    public void setIsubrid(String isubrid) {
        this.isubrid = isubrid == null ? null : isubrid.trim();
    }

    public Integer getIsubrep() {
        return isubrep;
    }

    public void setIsubrep(Integer isubrep) {
        this.isubrep = isubrep;
    }

    public Integer getIpusseq() {
        return ipusseq;
    }

    public void setIpusseq(Integer ipusseq) {
        this.ipusseq = ipusseq;
    }

    public String getIpgmnbr() {
        return ipgmnbr;
    }

    public void setIpgmnbr(String ipgmnbr) {
        this.ipgmnbr = ipgmnbr == null ? null : ipgmnbr.trim();
    }
}