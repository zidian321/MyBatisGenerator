package com.ibm.dk.alr.zscm.scrt.storing.mybatis.data;

import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.SCRPIC;
import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.SCRPICKey;

public interface SCRPICMapper {
    int deleteByPrimaryKey(SCRPICKey key);

    int insert(SCRPIC record);

    int insertSelective(SCRPIC record);

    SCRPIC selectByPrimaryKey(SCRPICKey key);

    int updateByPrimaryKeySelective(SCRPIC record);

    int updateByPrimaryKey(SCRPIC record);
}