package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

import java.util.Date;

public class WLMCSV {
    private String isubrid;

    private String lcsvfle;

    private Integer qcsvrow;

    private Date dcsvaut;

    private String ncsvauu;

    private String ncsvaup;

    private String fsubste;

    private Integer isubrep;

    public String getIsubrid() {
        return isubrid;
    }

    public void setIsubrid(String isubrid) {
        this.isubrid = isubrid == null ? null : isubrid.trim();
    }

    public String getLcsvfle() {
        return lcsvfle;
    }

    public void setLcsvfle(String lcsvfle) {
        this.lcsvfle = lcsvfle == null ? null : lcsvfle.trim();
    }

    public Integer getQcsvrow() {
        return qcsvrow;
    }

    public void setQcsvrow(Integer qcsvrow) {
        this.qcsvrow = qcsvrow;
    }

    public Date getDcsvaut() {
        return dcsvaut;
    }

    public void setDcsvaut(Date dcsvaut) {
        this.dcsvaut = dcsvaut;
    }

    public String getNcsvauu() {
        return ncsvauu;
    }

    public void setNcsvauu(String ncsvauu) {
        this.ncsvauu = ncsvauu == null ? null : ncsvauu.trim();
    }

    public String getNcsvaup() {
        return ncsvaup;
    }

    public void setNcsvaup(String ncsvaup) {
        this.ncsvaup = ncsvaup == null ? null : ncsvaup.trim();
    }

    public String getFsubste() {
        return fsubste;
    }

    public void setFsubste(String fsubste) {
        this.fsubste = fsubste == null ? null : fsubste.trim();
    }

    public Integer getIsubrep() {
        return isubrep;
    }

    public void setIsubrep(Integer isubrep) {
        this.isubrep = isubrep;
    }
}