package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class WLMDCSExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public WLMDCSExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdsuridIsNull() {
            addCriterion("IDSURID is null");
            return (Criteria) this;
        }

        public Criteria andIdsuridIsNotNull() {
            addCriterion("IDSURID is not null");
            return (Criteria) this;
        }

        public Criteria andIdsuridEqualTo(String value) {
            addCriterion("IDSURID =", value, "idsurid");
            return (Criteria) this;
        }

        public Criteria andIdsuridNotEqualTo(String value) {
            addCriterion("IDSURID <>", value, "idsurid");
            return (Criteria) this;
        }

        public Criteria andIdsuridGreaterThan(String value) {
            addCriterion("IDSURID >", value, "idsurid");
            return (Criteria) this;
        }

        public Criteria andIdsuridGreaterThanOrEqualTo(String value) {
            addCriterion("IDSURID >=", value, "idsurid");
            return (Criteria) this;
        }

        public Criteria andIdsuridLessThan(String value) {
            addCriterion("IDSURID <", value, "idsurid");
            return (Criteria) this;
        }

        public Criteria andIdsuridLessThanOrEqualTo(String value) {
            addCriterion("IDSURID <=", value, "idsurid");
            return (Criteria) this;
        }

        public Criteria andIdsuridLike(String value) {
            addCriterion("IDSURID like", value, "idsurid");
            return (Criteria) this;
        }

        public Criteria andIdsuridNotLike(String value) {
            addCriterion("IDSURID not like", value, "idsurid");
            return (Criteria) this;
        }

        public Criteria andIdsuridIn(List<String> values) {
            addCriterion("IDSURID in", values, "idsurid");
            return (Criteria) this;
        }

        public Criteria andIdsuridNotIn(List<String> values) {
            addCriterion("IDSURID not in", values, "idsurid");
            return (Criteria) this;
        }

        public Criteria andIdsuridBetween(String value1, String value2) {
            addCriterion("IDSURID between", value1, value2, "idsurid");
            return (Criteria) this;
        }

        public Criteria andIdsuridNotBetween(String value1, String value2) {
            addCriterion("IDSURID not between", value1, value2, "idsurid");
            return (Criteria) this;
        }

        public Criteria andLdcsfleIsNull() {
            addCriterion("LDCSFLE is null");
            return (Criteria) this;
        }

        public Criteria andLdcsfleIsNotNull() {
            addCriterion("LDCSFLE is not null");
            return (Criteria) this;
        }

        public Criteria andLdcsfleEqualTo(String value) {
            addCriterion("LDCSFLE =", value, "ldcsfle");
            return (Criteria) this;
        }

        public Criteria andLdcsfleNotEqualTo(String value) {
            addCriterion("LDCSFLE <>", value, "ldcsfle");
            return (Criteria) this;
        }

        public Criteria andLdcsfleGreaterThan(String value) {
            addCriterion("LDCSFLE >", value, "ldcsfle");
            return (Criteria) this;
        }

        public Criteria andLdcsfleGreaterThanOrEqualTo(String value) {
            addCriterion("LDCSFLE >=", value, "ldcsfle");
            return (Criteria) this;
        }

        public Criteria andLdcsfleLessThan(String value) {
            addCriterion("LDCSFLE <", value, "ldcsfle");
            return (Criteria) this;
        }

        public Criteria andLdcsfleLessThanOrEqualTo(String value) {
            addCriterion("LDCSFLE <=", value, "ldcsfle");
            return (Criteria) this;
        }

        public Criteria andLdcsfleLike(String value) {
            addCriterion("LDCSFLE like", value, "ldcsfle");
            return (Criteria) this;
        }

        public Criteria andLdcsfleNotLike(String value) {
            addCriterion("LDCSFLE not like", value, "ldcsfle");
            return (Criteria) this;
        }

        public Criteria andLdcsfleIn(List<String> values) {
            addCriterion("LDCSFLE in", values, "ldcsfle");
            return (Criteria) this;
        }

        public Criteria andLdcsfleNotIn(List<String> values) {
            addCriterion("LDCSFLE not in", values, "ldcsfle");
            return (Criteria) this;
        }

        public Criteria andLdcsfleBetween(String value1, String value2) {
            addCriterion("LDCSFLE between", value1, value2, "ldcsfle");
            return (Criteria) this;
        }

        public Criteria andLdcsfleNotBetween(String value1, String value2) {
            addCriterion("LDCSFLE not between", value1, value2, "ldcsfle");
            return (Criteria) this;
        }

        public Criteria andQdcsrowIsNull() {
            addCriterion("QDCSROW is null");
            return (Criteria) this;
        }

        public Criteria andQdcsrowIsNotNull() {
            addCriterion("QDCSROW is not null");
            return (Criteria) this;
        }

        public Criteria andQdcsrowEqualTo(Integer value) {
            addCriterion("QDCSROW =", value, "qdcsrow");
            return (Criteria) this;
        }

        public Criteria andQdcsrowNotEqualTo(Integer value) {
            addCriterion("QDCSROW <>", value, "qdcsrow");
            return (Criteria) this;
        }

        public Criteria andQdcsrowGreaterThan(Integer value) {
            addCriterion("QDCSROW >", value, "qdcsrow");
            return (Criteria) this;
        }

        public Criteria andQdcsrowGreaterThanOrEqualTo(Integer value) {
            addCriterion("QDCSROW >=", value, "qdcsrow");
            return (Criteria) this;
        }

        public Criteria andQdcsrowLessThan(Integer value) {
            addCriterion("QDCSROW <", value, "qdcsrow");
            return (Criteria) this;
        }

        public Criteria andQdcsrowLessThanOrEqualTo(Integer value) {
            addCriterion("QDCSROW <=", value, "qdcsrow");
            return (Criteria) this;
        }

        public Criteria andQdcsrowIn(List<Integer> values) {
            addCriterion("QDCSROW in", values, "qdcsrow");
            return (Criteria) this;
        }

        public Criteria andQdcsrowNotIn(List<Integer> values) {
            addCriterion("QDCSROW not in", values, "qdcsrow");
            return (Criteria) this;
        }

        public Criteria andQdcsrowBetween(Integer value1, Integer value2) {
            addCriterion("QDCSROW between", value1, value2, "qdcsrow");
            return (Criteria) this;
        }

        public Criteria andQdcsrowNotBetween(Integer value1, Integer value2) {
            addCriterion("QDCSROW not between", value1, value2, "qdcsrow");
            return (Criteria) this;
        }

        public Criteria andDdcsautIsNull() {
            addCriterion("DDCSAUT is null");
            return (Criteria) this;
        }

        public Criteria andDdcsautIsNotNull() {
            addCriterion("DDCSAUT is not null");
            return (Criteria) this;
        }

        public Criteria andDdcsautEqualTo(Date value) {
            addCriterion("DDCSAUT =", value, "ddcsaut");
            return (Criteria) this;
        }

        public Criteria andDdcsautNotEqualTo(Date value) {
            addCriterion("DDCSAUT <>", value, "ddcsaut");
            return (Criteria) this;
        }

        public Criteria andDdcsautGreaterThan(Date value) {
            addCriterion("DDCSAUT >", value, "ddcsaut");
            return (Criteria) this;
        }

        public Criteria andDdcsautGreaterThanOrEqualTo(Date value) {
            addCriterion("DDCSAUT >=", value, "ddcsaut");
            return (Criteria) this;
        }

        public Criteria andDdcsautLessThan(Date value) {
            addCriterion("DDCSAUT <", value, "ddcsaut");
            return (Criteria) this;
        }

        public Criteria andDdcsautLessThanOrEqualTo(Date value) {
            addCriterion("DDCSAUT <=", value, "ddcsaut");
            return (Criteria) this;
        }

        public Criteria andDdcsautIn(List<Date> values) {
            addCriterion("DDCSAUT in", values, "ddcsaut");
            return (Criteria) this;
        }

        public Criteria andDdcsautNotIn(List<Date> values) {
            addCriterion("DDCSAUT not in", values, "ddcsaut");
            return (Criteria) this;
        }

        public Criteria andDdcsautBetween(Date value1, Date value2) {
            addCriterion("DDCSAUT between", value1, value2, "ddcsaut");
            return (Criteria) this;
        }

        public Criteria andDdcsautNotBetween(Date value1, Date value2) {
            addCriterion("DDCSAUT not between", value1, value2, "ddcsaut");
            return (Criteria) this;
        }

        public Criteria andNdcsauuIsNull() {
            addCriterion("NDCSAUU is null");
            return (Criteria) this;
        }

        public Criteria andNdcsauuIsNotNull() {
            addCriterion("NDCSAUU is not null");
            return (Criteria) this;
        }

        public Criteria andNdcsauuEqualTo(String value) {
            addCriterion("NDCSAUU =", value, "ndcsauu");
            return (Criteria) this;
        }

        public Criteria andNdcsauuNotEqualTo(String value) {
            addCriterion("NDCSAUU <>", value, "ndcsauu");
            return (Criteria) this;
        }

        public Criteria andNdcsauuGreaterThan(String value) {
            addCriterion("NDCSAUU >", value, "ndcsauu");
            return (Criteria) this;
        }

        public Criteria andNdcsauuGreaterThanOrEqualTo(String value) {
            addCriterion("NDCSAUU >=", value, "ndcsauu");
            return (Criteria) this;
        }

        public Criteria andNdcsauuLessThan(String value) {
            addCriterion("NDCSAUU <", value, "ndcsauu");
            return (Criteria) this;
        }

        public Criteria andNdcsauuLessThanOrEqualTo(String value) {
            addCriterion("NDCSAUU <=", value, "ndcsauu");
            return (Criteria) this;
        }

        public Criteria andNdcsauuLike(String value) {
            addCriterion("NDCSAUU like", value, "ndcsauu");
            return (Criteria) this;
        }

        public Criteria andNdcsauuNotLike(String value) {
            addCriterion("NDCSAUU not like", value, "ndcsauu");
            return (Criteria) this;
        }

        public Criteria andNdcsauuIn(List<String> values) {
            addCriterion("NDCSAUU in", values, "ndcsauu");
            return (Criteria) this;
        }

        public Criteria andNdcsauuNotIn(List<String> values) {
            addCriterion("NDCSAUU not in", values, "ndcsauu");
            return (Criteria) this;
        }

        public Criteria andNdcsauuBetween(String value1, String value2) {
            addCriterion("NDCSAUU between", value1, value2, "ndcsauu");
            return (Criteria) this;
        }

        public Criteria andNdcsauuNotBetween(String value1, String value2) {
            addCriterion("NDCSAUU not between", value1, value2, "ndcsauu");
            return (Criteria) this;
        }

        public Criteria andNdcsaupIsNull() {
            addCriterion("NDCSAUP is null");
            return (Criteria) this;
        }

        public Criteria andNdcsaupIsNotNull() {
            addCriterion("NDCSAUP is not null");
            return (Criteria) this;
        }

        public Criteria andNdcsaupEqualTo(String value) {
            addCriterion("NDCSAUP =", value, "ndcsaup");
            return (Criteria) this;
        }

        public Criteria andNdcsaupNotEqualTo(String value) {
            addCriterion("NDCSAUP <>", value, "ndcsaup");
            return (Criteria) this;
        }

        public Criteria andNdcsaupGreaterThan(String value) {
            addCriterion("NDCSAUP >", value, "ndcsaup");
            return (Criteria) this;
        }

        public Criteria andNdcsaupGreaterThanOrEqualTo(String value) {
            addCriterion("NDCSAUP >=", value, "ndcsaup");
            return (Criteria) this;
        }

        public Criteria andNdcsaupLessThan(String value) {
            addCriterion("NDCSAUP <", value, "ndcsaup");
            return (Criteria) this;
        }

        public Criteria andNdcsaupLessThanOrEqualTo(String value) {
            addCriterion("NDCSAUP <=", value, "ndcsaup");
            return (Criteria) this;
        }

        public Criteria andNdcsaupLike(String value) {
            addCriterion("NDCSAUP like", value, "ndcsaup");
            return (Criteria) this;
        }

        public Criteria andNdcsaupNotLike(String value) {
            addCriterion("NDCSAUP not like", value, "ndcsaup");
            return (Criteria) this;
        }

        public Criteria andNdcsaupIn(List<String> values) {
            addCriterion("NDCSAUP in", values, "ndcsaup");
            return (Criteria) this;
        }

        public Criteria andNdcsaupNotIn(List<String> values) {
            addCriterion("NDCSAUP not in", values, "ndcsaup");
            return (Criteria) this;
        }

        public Criteria andNdcsaupBetween(String value1, String value2) {
            addCriterion("NDCSAUP between", value1, value2, "ndcsaup");
            return (Criteria) this;
        }

        public Criteria andNdcsaupNotBetween(String value1, String value2) {
            addCriterion("NDCSAUP not between", value1, value2, "ndcsaup");
            return (Criteria) this;
        }

        public Criteria andFdsusteIsNull() {
            addCriterion("FDSUSTE is null");
            return (Criteria) this;
        }

        public Criteria andFdsusteIsNotNull() {
            addCriterion("FDSUSTE is not null");
            return (Criteria) this;
        }

        public Criteria andFdsusteEqualTo(String value) {
            addCriterion("FDSUSTE =", value, "fdsuste");
            return (Criteria) this;
        }

        public Criteria andFdsusteNotEqualTo(String value) {
            addCriterion("FDSUSTE <>", value, "fdsuste");
            return (Criteria) this;
        }

        public Criteria andFdsusteGreaterThan(String value) {
            addCriterion("FDSUSTE >", value, "fdsuste");
            return (Criteria) this;
        }

        public Criteria andFdsusteGreaterThanOrEqualTo(String value) {
            addCriterion("FDSUSTE >=", value, "fdsuste");
            return (Criteria) this;
        }

        public Criteria andFdsusteLessThan(String value) {
            addCriterion("FDSUSTE <", value, "fdsuste");
            return (Criteria) this;
        }

        public Criteria andFdsusteLessThanOrEqualTo(String value) {
            addCriterion("FDSUSTE <=", value, "fdsuste");
            return (Criteria) this;
        }

        public Criteria andFdsusteLike(String value) {
            addCriterion("FDSUSTE like", value, "fdsuste");
            return (Criteria) this;
        }

        public Criteria andFdsusteNotLike(String value) {
            addCriterion("FDSUSTE not like", value, "fdsuste");
            return (Criteria) this;
        }

        public Criteria andFdsusteIn(List<String> values) {
            addCriterion("FDSUSTE in", values, "fdsuste");
            return (Criteria) this;
        }

        public Criteria andFdsusteNotIn(List<String> values) {
            addCriterion("FDSUSTE not in", values, "fdsuste");
            return (Criteria) this;
        }

        public Criteria andFdsusteBetween(String value1, String value2) {
            addCriterion("FDSUSTE between", value1, value2, "fdsuste");
            return (Criteria) this;
        }

        public Criteria andFdsusteNotBetween(String value1, String value2) {
            addCriterion("FDSUSTE not between", value1, value2, "fdsuste");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}