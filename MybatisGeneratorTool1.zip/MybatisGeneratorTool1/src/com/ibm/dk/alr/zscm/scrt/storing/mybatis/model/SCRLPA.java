package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

import java.util.Date;

public class SCRLPA {
    private Integer slpalpa;

    private String isubrid;

    private String nlpanam;

    private String ilpasys;

    private String ispcmch;

    private String dlpasta;

    private String dlpaend;

    private String nlpapct;

    private String nlpaccm;

    private Date dlpaaut;

    private String nlpaauu;

    private String nlpaaup;

    private Integer isubrep;

    public Integer getSlpalpa() {
        return slpalpa;
    }

    public void setSlpalpa(Integer slpalpa) {
        this.slpalpa = slpalpa;
    }

    public String getIsubrid() {
        return isubrid;
    }

    public void setIsubrid(String isubrid) {
        this.isubrid = isubrid == null ? null : isubrid.trim();
    }

    public String getNlpanam() {
        return nlpanam;
    }

    public void setNlpanam(String nlpanam) {
        this.nlpanam = nlpanam == null ? null : nlpanam.trim();
    }

    public String getIlpasys() {
        return ilpasys;
    }

    public void setIlpasys(String ilpasys) {
        this.ilpasys = ilpasys == null ? null : ilpasys.trim();
    }

    public String getIspcmch() {
        return ispcmch;
    }

    public void setIspcmch(String ispcmch) {
        this.ispcmch = ispcmch == null ? null : ispcmch.trim();
    }

    public String getDlpasta() {
        return dlpasta;
    }

    public void setDlpasta(String dlpasta) {
        this.dlpasta = dlpasta == null ? null : dlpasta.trim();
    }

    public String getDlpaend() {
        return dlpaend;
    }

    public void setDlpaend(String dlpaend) {
        this.dlpaend = dlpaend == null ? null : dlpaend.trim();
    }

    public String getNlpapct() {
        return nlpapct;
    }

    public void setNlpapct(String nlpapct) {
        this.nlpapct = nlpapct == null ? null : nlpapct.trim();
    }

    public String getNlpaccm() {
        return nlpaccm;
    }

    public void setNlpaccm(String nlpaccm) {
        this.nlpaccm = nlpaccm == null ? null : nlpaccm.trim();
    }

    public Date getDlpaaut() {
        return dlpaaut;
    }

    public void setDlpaaut(Date dlpaaut) {
        this.dlpaaut = dlpaaut;
    }

    public String getNlpaauu() {
        return nlpaauu;
    }

    public void setNlpaauu(String nlpaauu) {
        this.nlpaauu = nlpaauu == null ? null : nlpaauu.trim();
    }

    public String getNlpaaup() {
        return nlpaaup;
    }

    public void setNlpaaup(String nlpaaup) {
        this.nlpaaup = nlpaaup == null ? null : nlpaaup.trim();
    }

    public Integer getIsubrep() {
        return isubrep;
    }

    public void setIsubrep(Integer isubrep) {
        this.isubrep = isubrep;
    }
}