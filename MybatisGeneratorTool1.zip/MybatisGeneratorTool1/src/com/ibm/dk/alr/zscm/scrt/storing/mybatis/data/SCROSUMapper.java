package com.ibm.dk.alr.zscm.scrt.storing.mybatis.data;

import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.SCROSU;

public interface SCROSUMapper {
    int deleteByPrimaryKey(Integer sosuuid);

    int insert(SCROSU record);

    int insertSelective(SCROSU record);

    SCROSU selectByPrimaryKey(Integer sosuuid);

    int updateByPrimaryKeySelective(SCROSU record);

    int updateByPrimaryKey(SCROSU record);
}