package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

public class WLMMCNKey {
    private String imcndum;

    private String imcncus;

    private String imcncty;

    public String getImcndum() {
        return imcndum;
    }

    public void setImcndum(String imcndum) {
        this.imcndum = imcndum == null ? null : imcndum.trim();
    }

    public String getImcncus() {
        return imcncus;
    }

    public void setImcncus(String imcncus) {
        this.imcncus = imcncus == null ? null : imcncus.trim();
    }

    public String getImcncty() {
        return imcncty;
    }

    public void setImcncty(String imcncty) {
        this.imcncty = imcncty == null ? null : imcncty.trim();
    }
}