package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

import java.util.Date;

public class SCRSPO {
    private Integer sspospi;

    private Integer isposeq;

    private String ispoco1;

    private String ispoco2;

    private String ispoco3;

    private String ispoco4;

    private String ispoco5;

    private String ispoco6;

    private Integer sspssid;

    private Integer sosuuid;

    private Date dspoaut;

    private String nspoauu;

    private String nspoaup;

    private String ispoco7;

    private String ispoco8;

    public Integer getSspospi() {
        return sspospi;
    }

    public void setSspospi(Integer sspospi) {
        this.sspospi = sspospi;
    }

    public Integer getIsposeq() {
        return isposeq;
    }

    public void setIsposeq(Integer isposeq) {
        this.isposeq = isposeq;
    }

    public String getIspoco1() {
        return ispoco1;
    }

    public void setIspoco1(String ispoco1) {
        this.ispoco1 = ispoco1 == null ? null : ispoco1.trim();
    }

    public String getIspoco2() {
        return ispoco2;
    }

    public void setIspoco2(String ispoco2) {
        this.ispoco2 = ispoco2 == null ? null : ispoco2.trim();
    }

    public String getIspoco3() {
        return ispoco3;
    }

    public void setIspoco3(String ispoco3) {
        this.ispoco3 = ispoco3 == null ? null : ispoco3.trim();
    }

    public String getIspoco4() {
        return ispoco4;
    }

    public void setIspoco4(String ispoco4) {
        this.ispoco4 = ispoco4 == null ? null : ispoco4.trim();
    }

    public String getIspoco5() {
        return ispoco5;
    }

    public void setIspoco5(String ispoco5) {
        this.ispoco5 = ispoco5 == null ? null : ispoco5.trim();
    }

    public String getIspoco6() {
        return ispoco6;
    }

    public void setIspoco6(String ispoco6) {
        this.ispoco6 = ispoco6 == null ? null : ispoco6.trim();
    }

    public Integer getSspssid() {
        return sspssid;
    }

    public void setSspssid(Integer sspssid) {
        this.sspssid = sspssid;
    }

    public Integer getSosuuid() {
        return sosuuid;
    }

    public void setSosuuid(Integer sosuuid) {
        this.sosuuid = sosuuid;
    }

    public Date getDspoaut() {
        return dspoaut;
    }

    public void setDspoaut(Date dspoaut) {
        this.dspoaut = dspoaut;
    }

    public String getNspoauu() {
        return nspoauu;
    }

    public void setNspoauu(String nspoauu) {
        this.nspoauu = nspoauu == null ? null : nspoauu.trim();
    }

    public String getNspoaup() {
        return nspoaup;
    }

    public void setNspoaup(String nspoaup) {
        this.nspoaup = nspoaup == null ? null : nspoaup.trim();
    }

    public String getIspoco7() {
        return ispoco7;
    }

    public void setIspoco7(String ispoco7) {
        this.ispoco7 = ispoco7 == null ? null : ispoco7.trim();
    }

    public String getIspoco8() {
        return ispoco8;
    }

    public void setIspoco8(String ispoco8) {
        this.ispoco8 = ispoco8 == null ? null : ispoco8.trim();
    }
}