package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

public class WLMCPMKey {
    private String isubrid;

    private Integer isubrep;

    private String icpssid;

    private Integer icpmseq;

    public String getIsubrid() {
        return isubrid;
    }

    public void setIsubrid(String isubrid) {
        this.isubrid = isubrid == null ? null : isubrid.trim();
    }

    public Integer getIsubrep() {
        return isubrep;
    }

    public void setIsubrep(Integer isubrep) {
        this.isubrep = isubrep;
    }

    public String getIcpssid() {
        return icpssid;
    }

    public void setIcpssid(String icpssid) {
        this.icpssid = icpssid == null ? null : icpssid.trim();
    }

    public Integer getIcpmseq() {
        return icpmseq;
    }

    public void setIcpmseq(Integer icpmseq) {
        this.icpmseq = icpmseq;
    }
}