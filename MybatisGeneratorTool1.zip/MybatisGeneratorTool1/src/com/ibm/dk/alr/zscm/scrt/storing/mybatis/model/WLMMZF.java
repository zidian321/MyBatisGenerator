package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

import java.util.Date;

public class WLMMZF extends WLMMZFKey {
    private Date dmzfaut;

    private String nmzfauu;

    private String nmzfaup;

    private Object db2GeneratedRowidForLobs;

    private byte[] bmzffle;

    public Date getDmzfaut() {
        return dmzfaut;
    }

    public void setDmzfaut(Date dmzfaut) {
        this.dmzfaut = dmzfaut;
    }

    public String getNmzfauu() {
        return nmzfauu;
    }

    public void setNmzfauu(String nmzfauu) {
        this.nmzfauu = nmzfauu == null ? null : nmzfauu.trim();
    }

    public String getNmzfaup() {
        return nmzfaup;
    }

    public void setNmzfaup(String nmzfaup) {
        this.nmzfaup = nmzfaup == null ? null : nmzfaup.trim();
    }

    public Object getDb2GeneratedRowidForLobs() {
        return db2GeneratedRowidForLobs;
    }

    public void setDb2GeneratedRowidForLobs(Object db2GeneratedRowidForLobs) {
        this.db2GeneratedRowidForLobs = db2GeneratedRowidForLobs;
    }

    public byte[] getBmzffle() {
        return bmzffle;
    }

    public void setBmzffle(byte[] bmzffle) {
        this.bmzffle = bmzffle;
    }
}