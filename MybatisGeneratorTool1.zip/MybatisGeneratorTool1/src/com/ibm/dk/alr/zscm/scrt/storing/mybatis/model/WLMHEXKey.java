package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

public class WLMHEXKey {
    private String isubrid;

    private Integer isubrep;

    private String imetmet;

    private String imedmed;

    private String itxttid;

    public String getIsubrid() {
        return isubrid;
    }

    public void setIsubrid(String isubrid) {
        this.isubrid = isubrid == null ? null : isubrid.trim();
    }

    public Integer getIsubrep() {
        return isubrep;
    }

    public void setIsubrep(Integer isubrep) {
        this.isubrep = isubrep;
    }

    public String getImetmet() {
        return imetmet;
    }

    public void setImetmet(String imetmet) {
        this.imetmet = imetmet == null ? null : imetmet.trim();
    }

    public String getImedmed() {
        return imedmed;
    }

    public void setImedmed(String imedmed) {
        this.imedmed = imedmed == null ? null : imedmed.trim();
    }

    public String getItxttid() {
        return itxttid;
    }

    public void setItxttid(String itxttid) {
        this.itxttid = itxttid == null ? null : itxttid.trim();
    }
}