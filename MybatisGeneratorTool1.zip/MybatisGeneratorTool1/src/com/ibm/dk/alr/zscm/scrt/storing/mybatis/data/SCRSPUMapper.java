package com.ibm.dk.alr.zscm.scrt.storing.mybatis.data;

import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.SCRSPU;

public interface SCRSPUMapper {
    int deleteByPrimaryKey(Integer sspuspi);

    int insert(SCRSPU record);

    int insertSelective(SCRSPU record);

    SCRSPU selectByPrimaryKey(Integer sspuspi);

    int updateByPrimaryKeySelective(SCRSPU record);

    int updateByPrimaryKey(SCRSPU record);
}