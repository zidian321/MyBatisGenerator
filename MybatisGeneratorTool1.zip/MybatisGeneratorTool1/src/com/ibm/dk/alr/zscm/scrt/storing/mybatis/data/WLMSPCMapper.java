package com.ibm.dk.alr.zscm.scrt.storing.mybatis.data;

import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.WLMSPC;
import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.WLMSPCKey;

public interface WLMSPCMapper {
    int deleteByPrimaryKey(WLMSPCKey key);

    int insert(WLMSPC record);

    int insertSelective(WLMSPC record);

    WLMSPC selectByPrimaryKey(WLMSPCKey key);

    int updateByPrimaryKeySelective(WLMSPC record);

    int updateByPrimaryKey(WLMSPC record);
}