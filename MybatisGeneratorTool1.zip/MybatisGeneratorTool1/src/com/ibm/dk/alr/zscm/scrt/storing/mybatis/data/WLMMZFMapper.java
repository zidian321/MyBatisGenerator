package com.ibm.dk.alr.zscm.scrt.storing.mybatis.data;

import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.WLMMZF;
import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.WLMMZFKey;

public interface WLMMZFMapper {
    int deleteByPrimaryKey(WLMMZFKey key);

    int insert(WLMMZF record);

    int insertSelective(WLMMZF record);

    WLMMZF selectByPrimaryKey(WLMMZFKey key);

    int updateByPrimaryKeySelective(WLMMZF record);

    int updateByPrimaryKeyWithBLOBs(WLMMZF record);

    int updateByPrimaryKey(WLMMZF record);
}