package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

import java.util.Date;

public class WLMSPC extends WLMSPCKey {
    private Date dsubsts;

    private String cspccap;

    private String cspcval;

    private String fsubste;

    private String cspccaf;

    private String cspcrea;

    private String dperper;

    private Date dspcaut;

    private String sspcauu;

    private String sspcaup;

    private String ispcmch;

    private String fspcsns;

    private String fspcrep;

    private String fspcema;

    private String ispccus;

    private String ispccty;

    private Integer qspccou;

    private Integer qspcpmc;

    private Integer qspctmc;

    private String cspcica;

    private String cspcipl;

    private String ispccnm;

    private String cspctyp;

    private String cspcrem;

    private String fspcval;

    private String fspcdbc;

    public Date getDsubsts() {
        return dsubsts;
    }

    public void setDsubsts(Date dsubsts) {
        this.dsubsts = dsubsts;
    }

    public String getCspccap() {
        return cspccap;
    }

    public void setCspccap(String cspccap) {
        this.cspccap = cspccap == null ? null : cspccap.trim();
    }

    public String getCspcval() {
        return cspcval;
    }

    public void setCspcval(String cspcval) {
        this.cspcval = cspcval == null ? null : cspcval.trim();
    }

    public String getFsubste() {
        return fsubste;
    }

    public void setFsubste(String fsubste) {
        this.fsubste = fsubste == null ? null : fsubste.trim();
    }

    public String getCspccaf() {
        return cspccaf;
    }

    public void setCspccaf(String cspccaf) {
        this.cspccaf = cspccaf == null ? null : cspccaf.trim();
    }

    public String getCspcrea() {
        return cspcrea;
    }

    public void setCspcrea(String cspcrea) {
        this.cspcrea = cspcrea == null ? null : cspcrea.trim();
    }

    public String getDperper() {
        return dperper;
    }

    public void setDperper(String dperper) {
        this.dperper = dperper == null ? null : dperper.trim();
    }

    public Date getDspcaut() {
        return dspcaut;
    }

    public void setDspcaut(Date dspcaut) {
        this.dspcaut = dspcaut;
    }

    public String getSspcauu() {
        return sspcauu;
    }

    public void setSspcauu(String sspcauu) {
        this.sspcauu = sspcauu == null ? null : sspcauu.trim();
    }

    public String getSspcaup() {
        return sspcaup;
    }

    public void setSspcaup(String sspcaup) {
        this.sspcaup = sspcaup == null ? null : sspcaup.trim();
    }

    public String getIspcmch() {
        return ispcmch;
    }

    public void setIspcmch(String ispcmch) {
        this.ispcmch = ispcmch == null ? null : ispcmch.trim();
    }

    public String getFspcsns() {
        return fspcsns;
    }

    public void setFspcsns(String fspcsns) {
        this.fspcsns = fspcsns == null ? null : fspcsns.trim();
    }

    public String getFspcrep() {
        return fspcrep;
    }

    public void setFspcrep(String fspcrep) {
        this.fspcrep = fspcrep == null ? null : fspcrep.trim();
    }

    public String getFspcema() {
        return fspcema;
    }

    public void setFspcema(String fspcema) {
        this.fspcema = fspcema == null ? null : fspcema.trim();
    }

    public String getIspccus() {
        return ispccus;
    }

    public void setIspccus(String ispccus) {
        this.ispccus = ispccus == null ? null : ispccus.trim();
    }

    public String getIspccty() {
        return ispccty;
    }

    public void setIspccty(String ispccty) {
        this.ispccty = ispccty == null ? null : ispccty.trim();
    }

    public Integer getQspccou() {
        return qspccou;
    }

    public void setQspccou(Integer qspccou) {
        this.qspccou = qspccou;
    }

    public Integer getQspcpmc() {
        return qspcpmc;
    }

    public void setQspcpmc(Integer qspcpmc) {
        this.qspcpmc = qspcpmc;
    }

    public Integer getQspctmc() {
        return qspctmc;
    }

    public void setQspctmc(Integer qspctmc) {
        this.qspctmc = qspctmc;
    }

    public String getCspcica() {
        return cspcica;
    }

    public void setCspcica(String cspcica) {
        this.cspcica = cspcica == null ? null : cspcica.trim();
    }

    public String getCspcipl() {
        return cspcipl;
    }

    public void setCspcipl(String cspcipl) {
        this.cspcipl = cspcipl == null ? null : cspcipl.trim();
    }

    public String getIspccnm() {
        return ispccnm;
    }

    public void setIspccnm(String ispccnm) {
        this.ispccnm = ispccnm == null ? null : ispccnm.trim();
    }

    public String getCspctyp() {
        return cspctyp;
    }

    public void setCspctyp(String cspctyp) {
        this.cspctyp = cspctyp == null ? null : cspctyp.trim();
    }

    public String getCspcrem() {
        return cspcrem;
    }

    public void setCspcrem(String cspcrem) {
        this.cspcrem = cspcrem == null ? null : cspcrem.trim();
    }

    public String getFspcval() {
        return fspcval;
    }

    public void setFspcval(String fspcval) {
        this.fspcval = fspcval == null ? null : fspcval.trim();
    }

    public String getFspcdbc() {
        return fspcdbc;
    }

    public void setFspcdbc(String fspcdbc) {
        this.fspcdbc = fspcdbc == null ? null : fspcdbc.trim();
    }
}