package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

import java.util.Date;

public class SCRMOP extends SCRMOPKey {
    private String nprdnbr;

    private Integer imoptmu;

    private String dmoptme;

    private String svmskey;

    private String cmoptyp;

    private String nmopmpn;

    private Date dmopaut;

    private String smopauu;

    private String smopaup;

    public String getNprdnbr() {
        return nprdnbr;
    }

    public void setNprdnbr(String nprdnbr) {
        this.nprdnbr = nprdnbr == null ? null : nprdnbr.trim();
    }

    public Integer getImoptmu() {
        return imoptmu;
    }

    public void setImoptmu(Integer imoptmu) {
        this.imoptmu = imoptmu;
    }

    public String getDmoptme() {
        return dmoptme;
    }

    public void setDmoptme(String dmoptme) {
        this.dmoptme = dmoptme == null ? null : dmoptme.trim();
    }

    public String getSvmskey() {
        return svmskey;
    }

    public void setSvmskey(String svmskey) {
        this.svmskey = svmskey == null ? null : svmskey.trim();
    }

    public String getCmoptyp() {
        return cmoptyp;
    }

    public void setCmoptyp(String cmoptyp) {
        this.cmoptyp = cmoptyp == null ? null : cmoptyp.trim();
    }

    public String getNmopmpn() {
        return nmopmpn;
    }

    public void setNmopmpn(String nmopmpn) {
        this.nmopmpn = nmopmpn == null ? null : nmopmpn.trim();
    }

    public Date getDmopaut() {
        return dmopaut;
    }

    public void setDmopaut(Date dmopaut) {
        this.dmopaut = dmopaut;
    }

    public String getSmopauu() {
        return smopauu;
    }

    public void setSmopauu(String smopauu) {
        this.smopauu = smopauu == null ? null : smopauu.trim();
    }

    public String getSmopaup() {
        return smopaup;
    }

    public void setSmopaup(String smopaup) {
        this.smopaup = smopaup == null ? null : smopaup.trim();
    }
}