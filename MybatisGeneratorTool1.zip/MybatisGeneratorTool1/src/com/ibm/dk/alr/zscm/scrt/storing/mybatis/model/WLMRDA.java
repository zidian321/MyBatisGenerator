package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

import java.util.Date;

public class WLMRDA extends WLMRDAKey {
    private String lrdarda;

    private String srdaauu;

    private String srdaaup;

    private Date srdaaut;

    public String getLrdarda() {
        return lrdarda;
    }

    public void setLrdarda(String lrdarda) {
        this.lrdarda = lrdarda == null ? null : lrdarda.trim();
    }

    public String getSrdaauu() {
        return srdaauu;
    }

    public void setSrdaauu(String srdaauu) {
        this.srdaauu = srdaauu == null ? null : srdaauu.trim();
    }

    public String getSrdaaup() {
        return srdaaup;
    }

    public void setSrdaaup(String srdaaup) {
        this.srdaaup = srdaaup == null ? null : srdaaup.trim();
    }

    public Date getSrdaaut() {
        return srdaaut;
    }

    public void setSrdaaut(Date srdaaut) {
        this.srdaaut = srdaaut;
    }
}