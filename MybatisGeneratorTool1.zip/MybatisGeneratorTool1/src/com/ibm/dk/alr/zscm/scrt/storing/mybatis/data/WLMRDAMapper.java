package com.ibm.dk.alr.zscm.scrt.storing.mybatis.data;

import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.WLMRDA;
import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.WLMRDAKey;

public interface WLMRDAMapper {
    int deleteByPrimaryKey(WLMRDAKey key);

    int insert(WLMRDA record);

    int insertSelective(WLMRDA record);

    WLMRDA selectByPrimaryKey(WLMRDAKey key);

    int updateByPrimaryKeySelective(WLMRDA record);

    int updateByPrimaryKey(WLMRDA record);
}