package com.ibm.dk.alr.zscm.scrt.storing.mybatis.data;

import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.WLMHEX;
import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.WLMHEXKey;

public interface WLMHEXMapper {
    int deleteByPrimaryKey(WLMHEXKey key);

    int insert(WLMHEX record);

    int insertSelective(WLMHEX record);

    WLMHEX selectByPrimaryKey(WLMHEXKey key);

    int updateByPrimaryKeySelective(WLMHEX record);

    int updateByPrimaryKey(WLMHEX record);
}