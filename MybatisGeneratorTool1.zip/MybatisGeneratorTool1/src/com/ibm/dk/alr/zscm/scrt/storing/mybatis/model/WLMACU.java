package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

import java.util.Date;

public class WLMACU extends WLMACUKey {
    private String dperper;

    private String iacucid;

    private String ncpsnam;

    private Integer qacumsu;

    private Integer qacutmc;

    private Date dacuaut;

    private String sacuaup;

    private String sacuauu;

    public String getDperper() {
        return dperper;
    }

    public void setDperper(String dperper) {
        this.dperper = dperper == null ? null : dperper.trim();
    }

    public String getIacucid() {
        return iacucid;
    }

    public void setIacucid(String iacucid) {
        this.iacucid = iacucid == null ? null : iacucid.trim();
    }

    public String getNcpsnam() {
        return ncpsnam;
    }

    public void setNcpsnam(String ncpsnam) {
        this.ncpsnam = ncpsnam == null ? null : ncpsnam.trim();
    }

    public Integer getQacumsu() {
        return qacumsu;
    }

    public void setQacumsu(Integer qacumsu) {
        this.qacumsu = qacumsu;
    }

    public Integer getQacutmc() {
        return qacutmc;
    }

    public void setQacutmc(Integer qacutmc) {
        this.qacutmc = qacutmc;
    }

    public Date getDacuaut() {
        return dacuaut;
    }

    public void setDacuaut(Date dacuaut) {
        this.dacuaut = dacuaut;
    }

    public String getSacuaup() {
        return sacuaup;
    }

    public void setSacuaup(String sacuaup) {
        this.sacuaup = sacuaup == null ? null : sacuaup.trim();
    }

    public String getSacuauu() {
        return sacuauu;
    }

    public void setSacuauu(String sacuauu) {
        this.sacuauu = sacuauu == null ? null : sacuauu.trim();
    }
}