package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

import java.util.Date;

public class WLMDSU extends WLMDSUKey {
    private String ndsuuid;

    private String ndsuiid;

    private Date ndsusid;

    private String ndsucty;

    private String ndsuaid;

    private String fdsueml;

    private Date ddsusts;

    private Date ddsuuts;

    private String ndsunme;

    private String ndsueml;

    private String ndsuphn;

    private String ndsucnm;

    private String icusleg;

    private String ndsuhws;

    private String ndsuhwt;

    private String ndsuhwm;

    private String ndsutov;

    private String ndsutob;

    private String ndsutod;

    private String ndsuodc;

    private String ndsutrp;

    private Date ddsurps;

    private Date ddsurpe;

    private String ndsutpc;

    private String ndsutlp;

    private String qdsuzmu;

    private String qdsuzce;

    private String qdsuzpe;

    private String qdsuzme;

    private Date ddsuaut;

    private String ndsuauu;

    private String ndsuaup;

    private String fdsulat;

    private String fdsulow;

    private String fdsublv;

    private String fdsufdr;

    private String fdsuzos;

    private String fdsuipl;

    private String fdsumsu;

    private String fdsumig;

    private String ntodnme;

    private String ntodver;

    private String ntodrel;

    private String ictycty;

    private String idsumch;

    private String iusrusr;

    private String nsubcsf;

    private String ndsucsc;

    private String ndsuotp;

    private String ndsutfp;

    private String icuslef;

    private String fdsudbc;

    public String getNdsuuid() {
        return ndsuuid;
    }

    public void setNdsuuid(String ndsuuid) {
        this.ndsuuid = ndsuuid == null ? null : ndsuuid.trim();
    }

    public String getNdsuiid() {
        return ndsuiid;
    }

    public void setNdsuiid(String ndsuiid) {
        this.ndsuiid = ndsuiid == null ? null : ndsuiid.trim();
    }

    public Date getNdsusid() {
        return ndsusid;
    }

    public void setNdsusid(Date ndsusid) {
        this.ndsusid = ndsusid;
    }

    public String getNdsucty() {
        return ndsucty;
    }

    public void setNdsucty(String ndsucty) {
        this.ndsucty = ndsucty == null ? null : ndsucty.trim();
    }

    public String getNdsuaid() {
        return ndsuaid;
    }

    public void setNdsuaid(String ndsuaid) {
        this.ndsuaid = ndsuaid == null ? null : ndsuaid.trim();
    }

    public String getFdsueml() {
        return fdsueml;
    }

    public void setFdsueml(String fdsueml) {
        this.fdsueml = fdsueml == null ? null : fdsueml.trim();
    }

    public Date getDdsusts() {
        return ddsusts;
    }

    public void setDdsusts(Date ddsusts) {
        this.ddsusts = ddsusts;
    }

    public Date getDdsuuts() {
        return ddsuuts;
    }

    public void setDdsuuts(Date ddsuuts) {
        this.ddsuuts = ddsuuts;
    }

    public String getNdsunme() {
        return ndsunme;
    }

    public void setNdsunme(String ndsunme) {
        this.ndsunme = ndsunme == null ? null : ndsunme.trim();
    }

    public String getNdsueml() {
        return ndsueml;
    }

    public void setNdsueml(String ndsueml) {
        this.ndsueml = ndsueml == null ? null : ndsueml.trim();
    }

    public String getNdsuphn() {
        return ndsuphn;
    }

    public void setNdsuphn(String ndsuphn) {
        this.ndsuphn = ndsuphn == null ? null : ndsuphn.trim();
    }

    public String getNdsucnm() {
        return ndsucnm;
    }

    public void setNdsucnm(String ndsucnm) {
        this.ndsucnm = ndsucnm == null ? null : ndsucnm.trim();
    }

    public String getIcusleg() {
        return icusleg;
    }

    public void setIcusleg(String icusleg) {
        this.icusleg = icusleg == null ? null : icusleg.trim();
    }

    public String getNdsuhws() {
        return ndsuhws;
    }

    public void setNdsuhws(String ndsuhws) {
        this.ndsuhws = ndsuhws == null ? null : ndsuhws.trim();
    }

    public String getNdsuhwt() {
        return ndsuhwt;
    }

    public void setNdsuhwt(String ndsuhwt) {
        this.ndsuhwt = ndsuhwt == null ? null : ndsuhwt.trim();
    }

    public String getNdsuhwm() {
        return ndsuhwm;
    }

    public void setNdsuhwm(String ndsuhwm) {
        this.ndsuhwm = ndsuhwm == null ? null : ndsuhwm.trim();
    }

    public String getNdsutov() {
        return ndsutov;
    }

    public void setNdsutov(String ndsutov) {
        this.ndsutov = ndsutov == null ? null : ndsutov.trim();
    }

    public String getNdsutob() {
        return ndsutob;
    }

    public void setNdsutob(String ndsutob) {
        this.ndsutob = ndsutob == null ? null : ndsutob.trim();
    }

    public String getNdsutod() {
        return ndsutod;
    }

    public void setNdsutod(String ndsutod) {
        this.ndsutod = ndsutod == null ? null : ndsutod.trim();
    }

    public String getNdsuodc() {
        return ndsuodc;
    }

    public void setNdsuodc(String ndsuodc) {
        this.ndsuodc = ndsuodc == null ? null : ndsuodc.trim();
    }

    public String getNdsutrp() {
        return ndsutrp;
    }

    public void setNdsutrp(String ndsutrp) {
        this.ndsutrp = ndsutrp == null ? null : ndsutrp.trim();
    }

    public Date getDdsurps() {
        return ddsurps;
    }

    public void setDdsurps(Date ddsurps) {
        this.ddsurps = ddsurps;
    }

    public Date getDdsurpe() {
        return ddsurpe;
    }

    public void setDdsurpe(Date ddsurpe) {
        this.ddsurpe = ddsurpe;
    }

    public String getNdsutpc() {
        return ndsutpc;
    }

    public void setNdsutpc(String ndsutpc) {
        this.ndsutpc = ndsutpc == null ? null : ndsutpc.trim();
    }

    public String getNdsutlp() {
        return ndsutlp;
    }

    public void setNdsutlp(String ndsutlp) {
        this.ndsutlp = ndsutlp == null ? null : ndsutlp.trim();
    }

    public String getQdsuzmu() {
        return qdsuzmu;
    }

    public void setQdsuzmu(String qdsuzmu) {
        this.qdsuzmu = qdsuzmu == null ? null : qdsuzmu.trim();
    }

    public String getQdsuzce() {
        return qdsuzce;
    }

    public void setQdsuzce(String qdsuzce) {
        this.qdsuzce = qdsuzce == null ? null : qdsuzce.trim();
    }

    public String getQdsuzpe() {
        return qdsuzpe;
    }

    public void setQdsuzpe(String qdsuzpe) {
        this.qdsuzpe = qdsuzpe == null ? null : qdsuzpe.trim();
    }

    public String getQdsuzme() {
        return qdsuzme;
    }

    public void setQdsuzme(String qdsuzme) {
        this.qdsuzme = qdsuzme == null ? null : qdsuzme.trim();
    }

    public Date getDdsuaut() {
        return ddsuaut;
    }

    public void setDdsuaut(Date ddsuaut) {
        this.ddsuaut = ddsuaut;
    }

    public String getNdsuauu() {
        return ndsuauu;
    }

    public void setNdsuauu(String ndsuauu) {
        this.ndsuauu = ndsuauu == null ? null : ndsuauu.trim();
    }

    public String getNdsuaup() {
        return ndsuaup;
    }

    public void setNdsuaup(String ndsuaup) {
        this.ndsuaup = ndsuaup == null ? null : ndsuaup.trim();
    }

    public String getFdsulat() {
        return fdsulat;
    }

    public void setFdsulat(String fdsulat) {
        this.fdsulat = fdsulat == null ? null : fdsulat.trim();
    }

    public String getFdsulow() {
        return fdsulow;
    }

    public void setFdsulow(String fdsulow) {
        this.fdsulow = fdsulow == null ? null : fdsulow.trim();
    }

    public String getFdsublv() {
        return fdsublv;
    }

    public void setFdsublv(String fdsublv) {
        this.fdsublv = fdsublv == null ? null : fdsublv.trim();
    }

    public String getFdsufdr() {
        return fdsufdr;
    }

    public void setFdsufdr(String fdsufdr) {
        this.fdsufdr = fdsufdr == null ? null : fdsufdr.trim();
    }

    public String getFdsuzos() {
        return fdsuzos;
    }

    public void setFdsuzos(String fdsuzos) {
        this.fdsuzos = fdsuzos == null ? null : fdsuzos.trim();
    }

    public String getFdsuipl() {
        return fdsuipl;
    }

    public void setFdsuipl(String fdsuipl) {
        this.fdsuipl = fdsuipl == null ? null : fdsuipl.trim();
    }

    public String getFdsumsu() {
        return fdsumsu;
    }

    public void setFdsumsu(String fdsumsu) {
        this.fdsumsu = fdsumsu == null ? null : fdsumsu.trim();
    }

    public String getFdsumig() {
        return fdsumig;
    }

    public void setFdsumig(String fdsumig) {
        this.fdsumig = fdsumig == null ? null : fdsumig.trim();
    }

    public String getNtodnme() {
        return ntodnme;
    }

    public void setNtodnme(String ntodnme) {
        this.ntodnme = ntodnme == null ? null : ntodnme.trim();
    }

    public String getNtodver() {
        return ntodver;
    }

    public void setNtodver(String ntodver) {
        this.ntodver = ntodver == null ? null : ntodver.trim();
    }

    public String getNtodrel() {
        return ntodrel;
    }

    public void setNtodrel(String ntodrel) {
        this.ntodrel = ntodrel == null ? null : ntodrel.trim();
    }

    public String getIctycty() {
        return ictycty;
    }

    public void setIctycty(String ictycty) {
        this.ictycty = ictycty == null ? null : ictycty.trim();
    }

    public String getIdsumch() {
        return idsumch;
    }

    public void setIdsumch(String idsumch) {
        this.idsumch = idsumch == null ? null : idsumch.trim();
    }

    public String getIusrusr() {
        return iusrusr;
    }

    public void setIusrusr(String iusrusr) {
        this.iusrusr = iusrusr == null ? null : iusrusr.trim();
    }

    public String getNsubcsf() {
        return nsubcsf;
    }

    public void setNsubcsf(String nsubcsf) {
        this.nsubcsf = nsubcsf == null ? null : nsubcsf.trim();
    }

    public String getNdsucsc() {
        return ndsucsc;
    }

    public void setNdsucsc(String ndsucsc) {
        this.ndsucsc = ndsucsc == null ? null : ndsucsc.trim();
    }

    public String getNdsuotp() {
        return ndsuotp;
    }

    public void setNdsuotp(String ndsuotp) {
        this.ndsuotp = ndsuotp == null ? null : ndsuotp.trim();
    }

    public String getNdsutfp() {
        return ndsutfp;
    }

    public void setNdsutfp(String ndsutfp) {
        this.ndsutfp = ndsutfp == null ? null : ndsutfp.trim();
    }

    public String getIcuslef() {
        return icuslef;
    }

    public void setIcuslef(String icuslef) {
        this.icuslef = icuslef == null ? null : icuslef.trim();
    }

    public String getFdsudbc() {
        return fdsudbc;
    }

    public void setFdsudbc(String fdsudbc) {
        this.fdsudbc = fdsudbc == null ? null : fdsudbc.trim();
    }
}