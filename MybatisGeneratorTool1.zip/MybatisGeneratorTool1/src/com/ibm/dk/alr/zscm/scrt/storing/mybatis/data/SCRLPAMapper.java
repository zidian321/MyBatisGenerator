package com.ibm.dk.alr.zscm.scrt.storing.mybatis.data;

import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.SCRLPA;

public interface SCRLPAMapper {
    int deleteByPrimaryKey(Integer slpalpa);

    int insert(SCRLPA record);

    int insertSelective(SCRLPA record);

    SCRLPA selectByPrimaryKey(Integer slpalpa);

    int updateByPrimaryKeySelective(SCRLPA record);

    int updateByPrimaryKey(SCRLPA record);
}