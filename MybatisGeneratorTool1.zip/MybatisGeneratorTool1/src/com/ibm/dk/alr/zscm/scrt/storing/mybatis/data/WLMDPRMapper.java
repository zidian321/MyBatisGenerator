package com.ibm.dk.alr.zscm.scrt.storing.mybatis.data;

import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.WLMDPR;

public interface WLMDPRMapper {
    int insert(WLMDPR record);

    int insertSelective(WLMDPR record);
}