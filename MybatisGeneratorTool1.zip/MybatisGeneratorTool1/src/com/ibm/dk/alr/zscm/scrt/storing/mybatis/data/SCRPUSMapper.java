package com.ibm.dk.alr.zscm.scrt.storing.mybatis.data;

import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.SCRPUS;
import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.SCRPUSKey;

public interface SCRPUSMapper {
    int deleteByPrimaryKey(SCRPUSKey key);

    int insert(SCRPUS record);

    int insertSelective(SCRPUS record);

    SCRPUS selectByPrimaryKey(SCRPUSKey key);

    int updateByPrimaryKeySelective(SCRPUS record);

    int updateByPrimaryKey(SCRPUS record);
}