package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

import java.util.Date;

public class SCRMCP extends SCRMCPKey {
    private Integer imcpseq;

    private Integer qmcpmsu;

    private String dmcptme;

    private Date dmcpaut;

    private String smcpaup;

    private String smcpauu;

    public Integer getImcpseq() {
        return imcpseq;
    }

    public void setImcpseq(Integer imcpseq) {
        this.imcpseq = imcpseq;
    }

    public Integer getQmcpmsu() {
        return qmcpmsu;
    }

    public void setQmcpmsu(Integer qmcpmsu) {
        this.qmcpmsu = qmcpmsu;
    }

    public String getDmcptme() {
        return dmcptme;
    }

    public void setDmcptme(String dmcptme) {
        this.dmcptme = dmcptme == null ? null : dmcptme.trim();
    }

    public Date getDmcpaut() {
        return dmcpaut;
    }

    public void setDmcpaut(Date dmcpaut) {
        this.dmcpaut = dmcpaut;
    }

    public String getSmcpaup() {
        return smcpaup;
    }

    public void setSmcpaup(String smcpaup) {
        this.smcpaup = smcpaup == null ? null : smcpaup.trim();
    }

    public String getSmcpauu() {
        return smcpauu;
    }

    public void setSmcpauu(String smcpauu) {
        this.smcpauu = smcpauu == null ? null : smcpauu.trim();
    }
}