package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

import java.util.Date;

public class WLMMRF extends WLMMRFKey {
    private String lmrffle;

    private Date dmrfaut;

    private String smrfauu;

    private String smrfaup;

    public String getLmrffle() {
        return lmrffle;
    }

    public void setLmrffle(String lmrffle) {
        this.lmrffle = lmrffle == null ? null : lmrffle.trim();
    }

    public Date getDmrfaut() {
        return dmrfaut;
    }

    public void setDmrfaut(Date dmrfaut) {
        this.dmrfaut = dmrfaut;
    }

    public String getSmrfauu() {
        return smrfauu;
    }

    public void setSmrfauu(String smrfauu) {
        this.smrfauu = smrfauu == null ? null : smrfauu.trim();
    }

    public String getSmrfaup() {
        return smrfaup;
    }

    public void setSmrfaup(String smrfaup) {
        this.smrfaup = smrfaup == null ? null : smrfaup.trim();
    }
}