package com.ibm.dk.alr.zscm.scrt.storing.mybatis.data;

import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.SCRMLP;

public interface SCRMLPMapper {
    int insert(SCRMLP record);

    int insertSelective(SCRMLP record);
}