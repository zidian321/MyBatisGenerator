package com.ibm.dk.alr.zscm.scrt.storing.mybatis.data;

import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.WLMDSU;
import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.WLMDSUKey;

public interface WLMDSUMapper {
    int deleteByPrimaryKey(WLMDSUKey key);

    int insert(WLMDSU record);

    int insertSelective(WLMDSU record);

    WLMDSU selectByPrimaryKey(WLMDSUKey key);

    int updateByPrimaryKeySelective(WLMDSU record);

    int updateByPrimaryKey(WLMDSU record);
}