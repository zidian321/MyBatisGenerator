package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

import java.util.Date;

public class SCRMIM {
    private String isubmid;

    private String isubrid;

    private Integer isubrep;

    private String ispcmch;

    private String dperper;

    private String cmimkey;

    private Date dmimaut;

    private String smimauu;

    private String smimaup;

    private Integer imimseq;

    private Integer imimord;

    public String getIsubmid() {
        return isubmid;
    }

    public void setIsubmid(String isubmid) {
        this.isubmid = isubmid == null ? null : isubmid.trim();
    }

    public String getIsubrid() {
        return isubrid;
    }

    public void setIsubrid(String isubrid) {
        this.isubrid = isubrid == null ? null : isubrid.trim();
    }

    public Integer getIsubrep() {
        return isubrep;
    }

    public void setIsubrep(Integer isubrep) {
        this.isubrep = isubrep;
    }

    public String getIspcmch() {
        return ispcmch;
    }

    public void setIspcmch(String ispcmch) {
        this.ispcmch = ispcmch == null ? null : ispcmch.trim();
    }

    public String getDperper() {
        return dperper;
    }

    public void setDperper(String dperper) {
        this.dperper = dperper == null ? null : dperper.trim();
    }

    public String getCmimkey() {
        return cmimkey;
    }

    public void setCmimkey(String cmimkey) {
        this.cmimkey = cmimkey == null ? null : cmimkey.trim();
    }

    public Date getDmimaut() {
        return dmimaut;
    }

    public void setDmimaut(Date dmimaut) {
        this.dmimaut = dmimaut;
    }

    public String getSmimauu() {
        return smimauu;
    }

    public void setSmimauu(String smimauu) {
        this.smimauu = smimauu == null ? null : smimauu.trim();
    }

    public String getSmimaup() {
        return smimaup;
    }

    public void setSmimaup(String smimaup) {
        this.smimaup = smimaup == null ? null : smimaup.trim();
    }

    public Integer getImimseq() {
        return imimseq;
    }

    public void setImimseq(Integer imimseq) {
        this.imimseq = imimseq;
    }

    public Integer getImimord() {
        return imimord;
    }

    public void setImimord(Integer imimord) {
        this.imimord = imimord;
    }
}