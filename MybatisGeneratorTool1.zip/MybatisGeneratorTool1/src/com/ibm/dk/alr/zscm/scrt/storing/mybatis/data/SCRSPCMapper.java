package com.ibm.dk.alr.zscm.scrt.storing.mybatis.data;

import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.SCRSPC;
import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.SCRSPCKey;

public interface SCRSPCMapper {

    int deleteByPrimaryKey(SCRSPCKey key);

    int insert(SCRSPC record);

    int insertSelective(SCRSPC record);

    SCRSPC selectByPrimaryKey(SCRSPCKey key);

    int updateByPrimaryKeySelective(SCRSPC record);

    int updateByPrimaryKey(SCRSPC record);
}