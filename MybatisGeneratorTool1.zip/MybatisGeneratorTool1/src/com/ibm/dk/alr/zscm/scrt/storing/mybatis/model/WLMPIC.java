package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

import java.util.Date;

public class WLMPIC extends WLMPICKey {
    private String dperper;

    private String npiccpn;

    private String ipgmnbr;

    private String nprdnbr;

    private Date dpicaut;

    private String spicaup;

    private String spicauu;

    public String getDperper() {
        return dperper;
    }

    public void setDperper(String dperper) {
        this.dperper = dperper == null ? null : dperper.trim();
    }

    public String getNpiccpn() {
        return npiccpn;
    }

    public void setNpiccpn(String npiccpn) {
        this.npiccpn = npiccpn == null ? null : npiccpn.trim();
    }

    public String getIpgmnbr() {
        return ipgmnbr;
    }

    public void setIpgmnbr(String ipgmnbr) {
        this.ipgmnbr = ipgmnbr == null ? null : ipgmnbr.trim();
    }

    public String getNprdnbr() {
        return nprdnbr;
    }

    public void setNprdnbr(String nprdnbr) {
        this.nprdnbr = nprdnbr == null ? null : nprdnbr.trim();
    }

    public Date getDpicaut() {
        return dpicaut;
    }

    public void setDpicaut(Date dpicaut) {
        this.dpicaut = dpicaut;
    }

    public String getSpicaup() {
        return spicaup;
    }

    public void setSpicaup(String spicaup) {
        this.spicaup = spicaup == null ? null : spicaup.trim();
    }

    public String getSpicauu() {
        return spicauu;
    }

    public void setSpicauu(String spicauu) {
        this.spicauu = spicauu == null ? null : spicauu.trim();
    }
}