package com.ibm.dk.alr.zscm.scrt.storing.mybatis.data;

import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.WLMZMF;
import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.WLMZMFKey;

public interface WLMZMFMapper {
    int deleteByPrimaryKey(WLMZMFKey key);

    int insert(WLMZMF record);

    int insertSelective(WLMZMF record);

    WLMZMF selectByPrimaryKey(WLMZMFKey key);

    int updateByPrimaryKeySelective(WLMZMF record);

    int updateByPrimaryKeyWithBLOBs(WLMZMF record);

    int updateByPrimaryKey(WLMZMF record);
}