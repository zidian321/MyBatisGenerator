package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

import java.util.Date;

public class WLMDPR {
    private String idsurid;

    private String fdsuste;

    private String qdprtmu;

    private String qdprcmu;

    private String qdprccm;

    private String ndprnme;

    private String ndprnbr;

    private String cdprtpe;

    private Date ddpraut;

    private String ndprauu;

    private String ndpraup;

    public String getIdsurid() {
        return idsurid;
    }

    public void setIdsurid(String idsurid) {
        this.idsurid = idsurid == null ? null : idsurid.trim();
    }

    public String getFdsuste() {
        return fdsuste;
    }

    public void setFdsuste(String fdsuste) {
        this.fdsuste = fdsuste == null ? null : fdsuste.trim();
    }

    public String getQdprtmu() {
        return qdprtmu;
    }

    public void setQdprtmu(String qdprtmu) {
        this.qdprtmu = qdprtmu == null ? null : qdprtmu.trim();
    }

    public String getQdprcmu() {
        return qdprcmu;
    }

    public void setQdprcmu(String qdprcmu) {
        this.qdprcmu = qdprcmu == null ? null : qdprcmu.trim();
    }

    public String getQdprccm() {
        return qdprccm;
    }

    public void setQdprccm(String qdprccm) {
        this.qdprccm = qdprccm == null ? null : qdprccm.trim();
    }

    public String getNdprnme() {
        return ndprnme;
    }

    public void setNdprnme(String ndprnme) {
        this.ndprnme = ndprnme == null ? null : ndprnme.trim();
    }

    public String getNdprnbr() {
        return ndprnbr;
    }

    public void setNdprnbr(String ndprnbr) {
        this.ndprnbr = ndprnbr == null ? null : ndprnbr.trim();
    }

    public String getCdprtpe() {
        return cdprtpe;
    }

    public void setCdprtpe(String cdprtpe) {
        this.cdprtpe = cdprtpe == null ? null : cdprtpe.trim();
    }

    public Date getDdpraut() {
        return ddpraut;
    }

    public void setDdpraut(Date ddpraut) {
        this.ddpraut = ddpraut;
    }

    public String getNdprauu() {
        return ndprauu;
    }

    public void setNdprauu(String ndprauu) {
        this.ndprauu = ndprauu == null ? null : ndprauu.trim();
    }

    public String getNdpraup() {
        return ndpraup;
    }

    public void setNdpraup(String ndpraup) {
        this.ndpraup = ndpraup == null ? null : ndpraup.trim();
    }
}