package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

import java.util.Date;

public class WLMREP extends WLMREPKey {
    private String icusleg;

    private String irepmch;

    private String nreptrp;

    private Date dsubrps;

    private String srepauu;

    private String srepaup;

    private Date srepaut;

    public String getIcusleg() {
        return icusleg;
    }

    public void setIcusleg(String icusleg) {
        this.icusleg = icusleg == null ? null : icusleg.trim();
    }

    public String getIrepmch() {
        return irepmch;
    }

    public void setIrepmch(String irepmch) {
        this.irepmch = irepmch == null ? null : irepmch.trim();
    }

    public String getNreptrp() {
        return nreptrp;
    }

    public void setNreptrp(String nreptrp) {
        this.nreptrp = nreptrp == null ? null : nreptrp.trim();
    }

    public Date getDsubrps() {
        return dsubrps;
    }

    public void setDsubrps(Date dsubrps) {
        this.dsubrps = dsubrps;
    }

    public String getSrepauu() {
        return srepauu;
    }

    public void setSrepauu(String srepauu) {
        this.srepauu = srepauu == null ? null : srepauu.trim();
    }

    public String getSrepaup() {
        return srepaup;
    }

    public void setSrepaup(String srepaup) {
        this.srepaup = srepaup == null ? null : srepaup.trim();
    }

    public Date getSrepaut() {
        return srepaut;
    }

    public void setSrepaut(Date srepaut) {
        this.srepaut = srepaut;
    }
}