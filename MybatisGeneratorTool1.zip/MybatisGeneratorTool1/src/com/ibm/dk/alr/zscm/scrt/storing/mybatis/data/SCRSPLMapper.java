package com.ibm.dk.alr.zscm.scrt.storing.mybatis.data;

import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.SCRSPL;

public interface SCRSPLMapper {
    int insert(SCRSPL record);

    int insertSelective(SCRSPL record);
}