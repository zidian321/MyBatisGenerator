package com.ibm.dk.alr.zscm.scrt.storing.mybatis.data;

import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.WLMMRF;
import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.WLMMRFKey;

public interface WLMMRFMapper {
    int deleteByPrimaryKey(WLMMRFKey key);

    int insert(WLMMRF record);

    int insertSelective(WLMMRF record);

    WLMMRF selectByPrimaryKey(WLMMRFKey key);

    int updateByPrimaryKeySelective(WLMMRF record);

    int updateByPrimaryKey(WLMMRF record);
}