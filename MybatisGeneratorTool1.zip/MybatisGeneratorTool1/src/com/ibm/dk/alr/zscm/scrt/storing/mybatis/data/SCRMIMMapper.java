package com.ibm.dk.alr.zscm.scrt.storing.mybatis.data;

import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.SCRMIM;

public interface SCRMIMMapper {
    int insert(SCRMIM record);

    int insertSelective(SCRMIM record);
}