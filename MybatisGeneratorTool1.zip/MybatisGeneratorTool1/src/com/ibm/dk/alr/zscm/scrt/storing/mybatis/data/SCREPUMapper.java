package com.ibm.dk.alr.zscm.scrt.storing.mybatis.data;

import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.SCREPU;
import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.SCREPUKey;

public interface SCREPUMapper {
    int deleteByPrimaryKey(SCREPUKey key);

    int insert(SCREPU record);

    int insertSelective(SCREPU record);

    SCREPU selectByPrimaryKey(SCREPUKey key);

    int updateByPrimaryKeySelective(SCREPU record);

    int updateByPrimaryKey(SCREPU record);
}