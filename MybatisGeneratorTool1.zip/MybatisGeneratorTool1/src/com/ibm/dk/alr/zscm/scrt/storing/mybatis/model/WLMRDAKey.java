package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

public class WLMRDAKey {
    private String isubrid;

    private Integer isubrep;

    private String irdatyp;

    private Integer irdarow;

    public String getIsubrid() {
        return isubrid;
    }

    public void setIsubrid(String isubrid) {
        this.isubrid = isubrid == null ? null : isubrid.trim();
    }

    public Integer getIsubrep() {
        return isubrep;
    }

    public void setIsubrep(Integer isubrep) {
        this.isubrep = isubrep;
    }

    public String getIrdatyp() {
        return irdatyp;
    }

    public void setIrdatyp(String irdatyp) {
        this.irdatyp = irdatyp == null ? null : irdatyp.trim();
    }

    public Integer getIrdarow() {
        return irdarow;
    }

    public void setIrdarow(Integer irdarow) {
        this.irdarow = irdarow;
    }
}