package com.ibm.dk.alr.zscm.scrt.storing.mybatis.data;

import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.WLMCSV;

public interface WLMCSVMapper {
    int insert(WLMCSV record);

    int insertSelective(WLMCSV record);
}