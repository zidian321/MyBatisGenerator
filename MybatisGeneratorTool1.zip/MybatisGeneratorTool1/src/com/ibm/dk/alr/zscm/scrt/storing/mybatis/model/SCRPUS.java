package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

import java.util.Date;

public class SCRPUS extends SCRPUSKey {
    private String nprdnbr;

    private String qpustmu;

    private String qpuscmu;

    private String cpusccm;

    private String svmskey;

    private String fpusent;

    private String cpustyp;

    private Date dpusaut;

    private String npusauu;

    private String npusaup;

    private String cpusftn;

    private String qpushrs;

    private String npusspn;

    private String qpustrm;

    private String qpuscrm;

    public String getNprdnbr() {
        return nprdnbr;
    }

    public void setNprdnbr(String nprdnbr) {
        this.nprdnbr = nprdnbr == null ? null : nprdnbr.trim();
    }

    public String getQpustmu() {
        return qpustmu;
    }

    public void setQpustmu(String qpustmu) {
        this.qpustmu = qpustmu == null ? null : qpustmu.trim();
    }

    public String getQpuscmu() {
        return qpuscmu;
    }

    public void setQpuscmu(String qpuscmu) {
        this.qpuscmu = qpuscmu == null ? null : qpuscmu.trim();
    }

    public String getCpusccm() {
        return cpusccm;
    }

    public void setCpusccm(String cpusccm) {
        this.cpusccm = cpusccm == null ? null : cpusccm.trim();
    }

    public String getSvmskey() {
        return svmskey;
    }

    public void setSvmskey(String svmskey) {
        this.svmskey = svmskey == null ? null : svmskey.trim();
    }

    public String getFpusent() {
        return fpusent;
    }

    public void setFpusent(String fpusent) {
        this.fpusent = fpusent == null ? null : fpusent.trim();
    }

    public String getCpustyp() {
        return cpustyp;
    }

    public void setCpustyp(String cpustyp) {
        this.cpustyp = cpustyp == null ? null : cpustyp.trim();
    }

    public Date getDpusaut() {
        return dpusaut;
    }

    public void setDpusaut(Date dpusaut) {
        this.dpusaut = dpusaut;
    }

    public String getNpusauu() {
        return npusauu;
    }

    public void setNpusauu(String npusauu) {
        this.npusauu = npusauu == null ? null : npusauu.trim();
    }

    public String getNpusaup() {
        return npusaup;
    }

    public void setNpusaup(String npusaup) {
        this.npusaup = npusaup == null ? null : npusaup.trim();
    }

    public String getCpusftn() {
        return cpusftn;
    }

    public void setCpusftn(String cpusftn) {
        this.cpusftn = cpusftn == null ? null : cpusftn.trim();
    }

    public String getQpushrs() {
        return qpushrs;
    }

    public void setQpushrs(String qpushrs) {
        this.qpushrs = qpushrs == null ? null : qpushrs.trim();
    }

    public String getNpusspn() {
        return npusspn;
    }

    public void setNpusspn(String npusspn) {
        this.npusspn = npusspn == null ? null : npusspn.trim();
    }

    public String getQpustrm() {
        return qpustrm;
    }

    public void setQpustrm(String qpustrm) {
        this.qpustrm = qpustrm == null ? null : qpustrm.trim();
    }

    public String getQpuscrm() {
        return qpuscrm;
    }

    public void setQpuscrm(String qpuscrm) {
        this.qpuscrm = qpuscrm == null ? null : qpuscrm.trim();
    }
}