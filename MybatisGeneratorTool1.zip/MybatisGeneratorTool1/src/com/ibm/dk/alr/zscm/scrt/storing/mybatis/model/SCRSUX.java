package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

import java.util.Date;

public class SCRSUX extends SCRSUXKey {
    private String fsuxsta;

    private String csuxrda;

    private String nsuxtov;

    private String nsuxdtl;

    private String nsuxgcc;

    private String nsuxnme;

    private String nsuxphn;

    private String nsuxeml;

    private Date dsuxsts;

    private Date dsuxuts;

    private String icusleg;

    private String nsuxcnm;

    private String isuxhws;

    private String isuxhwt;

    private String nsuxmsu;

    private String ispcmch;

    private String ntodnme;

    private String ntodver;

    private String ntodrel;

    private String ictycty;

    private Date dsuxpst;

    private Date dsuxpen;

    private String nsuxaid;

    private String fsuxbsc;

    private String dperper;

    private Date dsuxaut;

    private String nsuxauu;

    private String nsuxaup;

    private String fsuxipl;

    private String csuxper;

    private String nsuxuid;

    private String nsuxiid;

    private Date nsuxsid;

    private String nsuxcty;

    private String icuspro;

    private String nsuxres;

    private String fsuxeml;

    private String fsuxmco;

    private String fsuxcfs;

    private String fsuxhas;

    private String nsuxcfe;

    private String nsuxhas;

    private String fsuxmvm;

    private String nsuxlag;

    private String fsuxlpa;

    public String getFsuxsta() {
        return fsuxsta;
    }

    public void setFsuxsta(String fsuxsta) {
        this.fsuxsta = fsuxsta == null ? null : fsuxsta.trim();
    }

    public String getCsuxrda() {
        return csuxrda;
    }

    public void setCsuxrda(String csuxrda) {
        this.csuxrda = csuxrda == null ? null : csuxrda.trim();
    }

    public String getNsuxtov() {
        return nsuxtov;
    }

    public void setNsuxtov(String nsuxtov) {
        this.nsuxtov = nsuxtov == null ? null : nsuxtov.trim();
    }

    public String getNsuxdtl() {
        return nsuxdtl;
    }

    public void setNsuxdtl(String nsuxdtl) {
        this.nsuxdtl = nsuxdtl == null ? null : nsuxdtl.trim();
    }

    public String getNsuxgcc() {
        return nsuxgcc;
    }

    public void setNsuxgcc(String nsuxgcc) {
        this.nsuxgcc = nsuxgcc == null ? null : nsuxgcc.trim();
    }

    public String getNsuxnme() {
        return nsuxnme;
    }

    public void setNsuxnme(String nsuxnme) {
        this.nsuxnme = nsuxnme == null ? null : nsuxnme.trim();
    }

    public String getNsuxphn() {
        return nsuxphn;
    }

    public void setNsuxphn(String nsuxphn) {
        this.nsuxphn = nsuxphn == null ? null : nsuxphn.trim();
    }

    public String getNsuxeml() {
        return nsuxeml;
    }

    public void setNsuxeml(String nsuxeml) {
        this.nsuxeml = nsuxeml == null ? null : nsuxeml.trim();
    }

    public Date getDsuxsts() {
        return dsuxsts;
    }

    public void setDsuxsts(Date dsuxsts) {
        this.dsuxsts = dsuxsts;
    }

    public Date getDsuxuts() {
        return dsuxuts;
    }

    public void setDsuxuts(Date dsuxuts) {
        this.dsuxuts = dsuxuts;
    }

    public String getIcusleg() {
        return icusleg;
    }

    public void setIcusleg(String icusleg) {
        this.icusleg = icusleg == null ? null : icusleg.trim();
    }

    public String getNsuxcnm() {
        return nsuxcnm;
    }

    public void setNsuxcnm(String nsuxcnm) {
        this.nsuxcnm = nsuxcnm == null ? null : nsuxcnm.trim();
    }

    public String getIsuxhws() {
        return isuxhws;
    }

    public void setIsuxhws(String isuxhws) {
        this.isuxhws = isuxhws == null ? null : isuxhws.trim();
    }

    public String getIsuxhwt() {
        return isuxhwt;
    }

    public void setIsuxhwt(String isuxhwt) {
        this.isuxhwt = isuxhwt == null ? null : isuxhwt.trim();
    }

    public String getNsuxmsu() {
        return nsuxmsu;
    }

    public void setNsuxmsu(String nsuxmsu) {
        this.nsuxmsu = nsuxmsu == null ? null : nsuxmsu.trim();
    }

    public String getIspcmch() {
        return ispcmch;
    }

    public void setIspcmch(String ispcmch) {
        this.ispcmch = ispcmch == null ? null : ispcmch.trim();
    }

    public String getNtodnme() {
        return ntodnme;
    }

    public void setNtodnme(String ntodnme) {
        this.ntodnme = ntodnme == null ? null : ntodnme.trim();
    }

    public String getNtodver() {
        return ntodver;
    }

    public void setNtodver(String ntodver) {
        this.ntodver = ntodver == null ? null : ntodver.trim();
    }

    public String getNtodrel() {
        return ntodrel;
    }

    public void setNtodrel(String ntodrel) {
        this.ntodrel = ntodrel == null ? null : ntodrel.trim();
    }

    public String getIctycty() {
        return ictycty;
    }

    public void setIctycty(String ictycty) {
        this.ictycty = ictycty == null ? null : ictycty.trim();
    }

    public Date getDsuxpst() {
        return dsuxpst;
    }

    public void setDsuxpst(Date dsuxpst) {
        this.dsuxpst = dsuxpst;
    }

    public Date getDsuxpen() {
        return dsuxpen;
    }

    public void setDsuxpen(Date dsuxpen) {
        this.dsuxpen = dsuxpen;
    }

    public String getNsuxaid() {
        return nsuxaid;
    }

    public void setNsuxaid(String nsuxaid) {
        this.nsuxaid = nsuxaid == null ? null : nsuxaid.trim();
    }

    public String getFsuxbsc() {
        return fsuxbsc;
    }

    public void setFsuxbsc(String fsuxbsc) {
        this.fsuxbsc = fsuxbsc == null ? null : fsuxbsc.trim();
    }

    public String getDperper() {
        return dperper;
    }

    public void setDperper(String dperper) {
        this.dperper = dperper == null ? null : dperper.trim();
    }

    public Date getDsuxaut() {
        return dsuxaut;
    }

    public void setDsuxaut(Date dsuxaut) {
        this.dsuxaut = dsuxaut;
    }

    public String getNsuxauu() {
        return nsuxauu;
    }

    public void setNsuxauu(String nsuxauu) {
        this.nsuxauu = nsuxauu == null ? null : nsuxauu.trim();
    }

    public String getNsuxaup() {
        return nsuxaup;
    }

    public void setNsuxaup(String nsuxaup) {
        this.nsuxaup = nsuxaup == null ? null : nsuxaup.trim();
    }

    public String getFsuxipl() {
        return fsuxipl;
    }

    public void setFsuxipl(String fsuxipl) {
        this.fsuxipl = fsuxipl == null ? null : fsuxipl.trim();
    }

    public String getCsuxper() {
        return csuxper;
    }

    public void setCsuxper(String csuxper) {
        this.csuxper = csuxper == null ? null : csuxper.trim();
    }

    public String getNsuxuid() {
        return nsuxuid;
    }

    public void setNsuxuid(String nsuxuid) {
        this.nsuxuid = nsuxuid == null ? null : nsuxuid.trim();
    }

    public String getNsuxiid() {
        return nsuxiid;
    }

    public void setNsuxiid(String nsuxiid) {
        this.nsuxiid = nsuxiid == null ? null : nsuxiid.trim();
    }

    public Date getNsuxsid() {
        return nsuxsid;
    }

    public void setNsuxsid(Date nsuxsid) {
        this.nsuxsid = nsuxsid;
    }

    public String getNsuxcty() {
        return nsuxcty;
    }

    public void setNsuxcty(String nsuxcty) {
        this.nsuxcty = nsuxcty == null ? null : nsuxcty.trim();
    }

    public String getIcuspro() {
        return icuspro;
    }

    public void setIcuspro(String icuspro) {
        this.icuspro = icuspro == null ? null : icuspro.trim();
    }

    public String getNsuxres() {
        return nsuxres;
    }

    public void setNsuxres(String nsuxres) {
        this.nsuxres = nsuxres == null ? null : nsuxres.trim();
    }

    public String getFsuxeml() {
        return fsuxeml;
    }

    public void setFsuxeml(String fsuxeml) {
        this.fsuxeml = fsuxeml == null ? null : fsuxeml.trim();
    }

    public String getFsuxmco() {
        return fsuxmco;
    }

    public void setFsuxmco(String fsuxmco) {
        this.fsuxmco = fsuxmco == null ? null : fsuxmco.trim();
    }

    public String getFsuxcfs() {
        return fsuxcfs;
    }

    public void setFsuxcfs(String fsuxcfs) {
        this.fsuxcfs = fsuxcfs == null ? null : fsuxcfs.trim();
    }

    public String getFsuxhas() {
        return fsuxhas;
    }

    public void setFsuxhas(String fsuxhas) {
        this.fsuxhas = fsuxhas == null ? null : fsuxhas.trim();
    }

    public String getNsuxcfe() {
        return nsuxcfe;
    }

    public void setNsuxcfe(String nsuxcfe) {
        this.nsuxcfe = nsuxcfe == null ? null : nsuxcfe.trim();
    }

    public String getNsuxhas() {
        return nsuxhas;
    }

    public void setNsuxhas(String nsuxhas) {
        this.nsuxhas = nsuxhas == null ? null : nsuxhas.trim();
    }

    public String getFsuxmvm() {
        return fsuxmvm;
    }

    public void setFsuxmvm(String fsuxmvm) {
        this.fsuxmvm = fsuxmvm == null ? null : fsuxmvm.trim();
    }

    public String getNsuxlag() {
        return nsuxlag;
    }

    public void setNsuxlag(String nsuxlag) {
        this.nsuxlag = nsuxlag == null ? null : nsuxlag.trim();
    }

    public String getFsuxlpa() {
        return fsuxlpa;
    }

    public void setFsuxlpa(String fsuxlpa) {
        this.fsuxlpa = fsuxlpa == null ? null : fsuxlpa.trim();
    }
}