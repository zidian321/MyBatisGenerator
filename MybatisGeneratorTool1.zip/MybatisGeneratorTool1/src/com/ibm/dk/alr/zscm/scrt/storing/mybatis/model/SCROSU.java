package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

import java.util.Date;

public class SCROSU {
    private Integer sosuuid;

    private String iosfidk;

    private Integer sosccid;

    private String isubrid;

    private String fosulow;

    private String nosutpc;

    private String cosutlp;

    private Date dosuaut;

    private String nosuauu;

    private String nosuaup;

    private Integer isubrep;

    public Integer getSosuuid() {
        return sosuuid;
    }

    public void setSosuuid(Integer sosuuid) {
        this.sosuuid = sosuuid;
    }

    public String getIosfidk() {
        return iosfidk;
    }

    public void setIosfidk(String iosfidk) {
        this.iosfidk = iosfidk == null ? null : iosfidk.trim();
    }

    public Integer getSosccid() {
        return sosccid;
    }

    public void setSosccid(Integer sosccid) {
        this.sosccid = sosccid;
    }

    public String getIsubrid() {
        return isubrid;
    }

    public void setIsubrid(String isubrid) {
        this.isubrid = isubrid == null ? null : isubrid.trim();
    }

    public String getFosulow() {
        return fosulow;
    }

    public void setFosulow(String fosulow) {
        this.fosulow = fosulow == null ? null : fosulow.trim();
    }

    public String getNosutpc() {
        return nosutpc;
    }

    public void setNosutpc(String nosutpc) {
        this.nosutpc = nosutpc == null ? null : nosutpc.trim();
    }

    public String getCosutlp() {
        return cosutlp;
    }

    public void setCosutlp(String cosutlp) {
        this.cosutlp = cosutlp == null ? null : cosutlp.trim();
    }

    public Date getDosuaut() {
        return dosuaut;
    }

    public void setDosuaut(Date dosuaut) {
        this.dosuaut = dosuaut;
    }

    public String getNosuauu() {
        return nosuauu;
    }

    public void setNosuauu(String nosuauu) {
        this.nosuauu = nosuauu == null ? null : nosuauu.trim();
    }

    public String getNosuaup() {
        return nosuaup;
    }

    public void setNosuaup(String nosuaup) {
        this.nosuaup = nosuaup == null ? null : nosuaup.trim();
    }

    public Integer getIsubrep() {
        return isubrep;
    }

    public void setIsubrep(Integer isubrep) {
        this.isubrep = isubrep;
    }
}