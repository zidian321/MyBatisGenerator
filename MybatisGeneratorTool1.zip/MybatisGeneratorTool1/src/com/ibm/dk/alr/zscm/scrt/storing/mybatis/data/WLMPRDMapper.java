package com.ibm.dk.alr.zscm.scrt.storing.mybatis.data;

import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.WLMPRD;

public interface WLMPRDMapper {
    int insert(WLMPRD record);

    int insertSelective(WLMPRD record);
}