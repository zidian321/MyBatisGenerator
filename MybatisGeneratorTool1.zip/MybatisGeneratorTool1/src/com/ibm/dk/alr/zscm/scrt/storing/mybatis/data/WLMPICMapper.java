package com.ibm.dk.alr.zscm.scrt.storing.mybatis.data;

import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.WLMPIC;
import com.ibm.dk.alr.zscm.scrt.storing.mybatis.model.WLMPICKey;

public interface WLMPICMapper {
    int deleteByPrimaryKey(WLMPICKey key);

    int insert(WLMPIC record);

    int insertSelective(WLMPIC record);

    WLMPIC selectByPrimaryKey(WLMPICKey key);

    int updateByPrimaryKeySelective(WLMPIC record);

    int updateByPrimaryKey(WLMPIC record);
}