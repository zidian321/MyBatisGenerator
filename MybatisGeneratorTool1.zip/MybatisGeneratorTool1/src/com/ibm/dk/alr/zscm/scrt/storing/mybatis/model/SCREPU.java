package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

import java.util.Date;

public class SCREPU extends SCREPUKey {
    private String nprdnbr;

    private Integer qepuepu;

    private Integer qepumpu;

    private String depudat;

    private Date depuaut;

    private String sepuauu;

    private String sepuaup;

    public String getNprdnbr() {
        return nprdnbr;
    }

    public void setNprdnbr(String nprdnbr) {
        this.nprdnbr = nprdnbr == null ? null : nprdnbr.trim();
    }

    public Integer getQepuepu() {
        return qepuepu;
    }

    public void setQepuepu(Integer qepuepu) {
        this.qepuepu = qepuepu;
    }

    public Integer getQepumpu() {
        return qepumpu;
    }

    public void setQepumpu(Integer qepumpu) {
        this.qepumpu = qepumpu;
    }

    public String getDepudat() {
        return depudat;
    }

    public void setDepudat(String depudat) {
        this.depudat = depudat == null ? null : depudat.trim();
    }

    public Date getDepuaut() {
        return depuaut;
    }

    public void setDepuaut(Date depuaut) {
        this.depuaut = depuaut;
    }

    public String getSepuauu() {
        return sepuauu;
    }

    public void setSepuauu(String sepuauu) {
        this.sepuauu = sepuauu == null ? null : sepuauu.trim();
    }

    public String getSepuaup() {
        return sepuaup;
    }

    public void setSepuaup(String sepuaup) {
        this.sepuaup = sepuaup == null ? null : sepuaup.trim();
    }
}