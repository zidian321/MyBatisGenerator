package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

public class SCRMOPKey {
    private String isubmid;

    private Integer isubrep;

    private String ipgmnbr;

    private Integer imopseq;

    public String getIsubmid() {
        return isubmid;
    }

    public void setIsubmid(String isubmid) {
        this.isubmid = isubmid == null ? null : isubmid.trim();
    }

    public Integer getIsubrep() {
        return isubrep;
    }

    public void setIsubrep(Integer isubrep) {
        this.isubrep = isubrep;
    }

    public String getIpgmnbr() {
        return ipgmnbr;
    }

    public void setIpgmnbr(String ipgmnbr) {
        this.ipgmnbr = ipgmnbr == null ? null : ipgmnbr.trim();
    }

    public Integer getImopseq() {
        return imopseq;
    }

    public void setImopseq(Integer imopseq) {
        this.imopseq = imopseq;
    }
}