package com.ibm.dk.alr.zscm.scrt.storing.mybatis.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SCRSPCExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public SCRSPCExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIsubridIsNull() {
            addCriterion("ISUBRID is null");
            return (Criteria) this;
        }

        public Criteria andIsubridIsNotNull() {
            addCriterion("ISUBRID is not null");
            return (Criteria) this;
        }

        public Criteria andIsubridEqualTo(String value) {
            addCriterion("ISUBRID =", value, "isubrid");
            return (Criteria) this;
        }

        public Criteria andIsubridNotEqualTo(String value) {
            addCriterion("ISUBRID <>", value, "isubrid");
            return (Criteria) this;
        }

        public Criteria andIsubridGreaterThan(String value) {
            addCriterion("ISUBRID >", value, "isubrid");
            return (Criteria) this;
        }

        public Criteria andIsubridGreaterThanOrEqualTo(String value) {
            addCriterion("ISUBRID >=", value, "isubrid");
            return (Criteria) this;
        }

        public Criteria andIsubridLessThan(String value) {
            addCriterion("ISUBRID <", value, "isubrid");
            return (Criteria) this;
        }

        public Criteria andIsubridLessThanOrEqualTo(String value) {
            addCriterion("ISUBRID <=", value, "isubrid");
            return (Criteria) this;
        }

        public Criteria andIsubridLike(String value) {
            addCriterion("ISUBRID like", value, "isubrid");
            return (Criteria) this;
        }

        public Criteria andIsubridNotLike(String value) {
            addCriterion("ISUBRID not like", value, "isubrid");
            return (Criteria) this;
        }

        public Criteria andIsubridIn(List<String> values) {
            addCriterion("ISUBRID in", values, "isubrid");
            return (Criteria) this;
        }

        public Criteria andIsubridNotIn(List<String> values) {
            addCriterion("ISUBRID not in", values, "isubrid");
            return (Criteria) this;
        }

        public Criteria andIsubridBetween(String value1, String value2) {
            addCriterion("ISUBRID between", value1, value2, "isubrid");
            return (Criteria) this;
        }

        public Criteria andIsubridNotBetween(String value1, String value2) {
            addCriterion("ISUBRID not between", value1, value2, "isubrid");
            return (Criteria) this;
        }

        public Criteria andIsubrepIsNull() {
            addCriterion("ISUBREP is null");
            return (Criteria) this;
        }

        public Criteria andIsubrepIsNotNull() {
            addCriterion("ISUBREP is not null");
            return (Criteria) this;
        }

        public Criteria andIsubrepEqualTo(Integer value) {
            addCriterion("ISUBREP =", value, "isubrep");
            return (Criteria) this;
        }

        public Criteria andIsubrepNotEqualTo(Integer value) {
            addCriterion("ISUBREP <>", value, "isubrep");
            return (Criteria) this;
        }

        public Criteria andIsubrepGreaterThan(Integer value) {
            addCriterion("ISUBREP >", value, "isubrep");
            return (Criteria) this;
        }

        public Criteria andIsubrepGreaterThanOrEqualTo(Integer value) {
            addCriterion("ISUBREP >=", value, "isubrep");
            return (Criteria) this;
        }

        public Criteria andIsubrepLessThan(Integer value) {
            addCriterion("ISUBREP <", value, "isubrep");
            return (Criteria) this;
        }

        public Criteria andIsubrepLessThanOrEqualTo(Integer value) {
            addCriterion("ISUBREP <=", value, "isubrep");
            return (Criteria) this;
        }

        public Criteria andIsubrepIn(List<Integer> values) {
            addCriterion("ISUBREP in", values, "isubrep");
            return (Criteria) this;
        }

        public Criteria andIsubrepNotIn(List<Integer> values) {
            addCriterion("ISUBREP not in", values, "isubrep");
            return (Criteria) this;
        }

        public Criteria andIsubrepBetween(Integer value1, Integer value2) {
            addCriterion("ISUBREP between", value1, value2, "isubrep");
            return (Criteria) this;
        }

        public Criteria andIsubrepNotBetween(Integer value1, Integer value2) {
            addCriterion("ISUBREP not between", value1, value2, "isubrep");
            return (Criteria) this;
        }

        public Criteria andDsubstsIsNull() {
            addCriterion("DSUBSTS is null");
            return (Criteria) this;
        }

        public Criteria andDsubstsIsNotNull() {
            addCriterion("DSUBSTS is not null");
            return (Criteria) this;
        }

        public Criteria andDsubstsEqualTo(Date value) {
            addCriterion("DSUBSTS =", value, "dsubsts");
            return (Criteria) this;
        }

        public Criteria andDsubstsNotEqualTo(Date value) {
            addCriterion("DSUBSTS <>", value, "dsubsts");
            return (Criteria) this;
        }

        public Criteria andDsubstsGreaterThan(Date value) {
            addCriterion("DSUBSTS >", value, "dsubsts");
            return (Criteria) this;
        }

        public Criteria andDsubstsGreaterThanOrEqualTo(Date value) {
            addCriterion("DSUBSTS >=", value, "dsubsts");
            return (Criteria) this;
        }

        public Criteria andDsubstsLessThan(Date value) {
            addCriterion("DSUBSTS <", value, "dsubsts");
            return (Criteria) this;
        }

        public Criteria andDsubstsLessThanOrEqualTo(Date value) {
            addCriterion("DSUBSTS <=", value, "dsubsts");
            return (Criteria) this;
        }

        public Criteria andDsubstsIn(List<Date> values) {
            addCriterion("DSUBSTS in", values, "dsubsts");
            return (Criteria) this;
        }

        public Criteria andDsubstsNotIn(List<Date> values) {
            addCriterion("DSUBSTS not in", values, "dsubsts");
            return (Criteria) this;
        }

        public Criteria andDsubstsBetween(Date value1, Date value2) {
            addCriterion("DSUBSTS between", value1, value2, "dsubsts");
            return (Criteria) this;
        }

        public Criteria andDsubstsNotBetween(Date value1, Date value2) {
            addCriterion("DSUBSTS not between", value1, value2, "dsubsts");
            return (Criteria) this;
        }

        public Criteria andCspccapIsNull() {
            addCriterion("CSPCCAP is null");
            return (Criteria) this;
        }

        public Criteria andCspccapIsNotNull() {
            addCriterion("CSPCCAP is not null");
            return (Criteria) this;
        }

        public Criteria andCspccapEqualTo(String value) {
            addCriterion("CSPCCAP =", value, "cspccap");
            return (Criteria) this;
        }

        public Criteria andCspccapNotEqualTo(String value) {
            addCriterion("CSPCCAP <>", value, "cspccap");
            return (Criteria) this;
        }

        public Criteria andCspccapGreaterThan(String value) {
            addCriterion("CSPCCAP >", value, "cspccap");
            return (Criteria) this;
        }

        public Criteria andCspccapGreaterThanOrEqualTo(String value) {
            addCriterion("CSPCCAP >=", value, "cspccap");
            return (Criteria) this;
        }

        public Criteria andCspccapLessThan(String value) {
            addCriterion("CSPCCAP <", value, "cspccap");
            return (Criteria) this;
        }

        public Criteria andCspccapLessThanOrEqualTo(String value) {
            addCriterion("CSPCCAP <=", value, "cspccap");
            return (Criteria) this;
        }

        public Criteria andCspccapLike(String value) {
            addCriterion("CSPCCAP like", value, "cspccap");
            return (Criteria) this;
        }

        public Criteria andCspccapNotLike(String value) {
            addCriterion("CSPCCAP not like", value, "cspccap");
            return (Criteria) this;
        }

        public Criteria andCspccapIn(List<String> values) {
            addCriterion("CSPCCAP in", values, "cspccap");
            return (Criteria) this;
        }

        public Criteria andCspccapNotIn(List<String> values) {
            addCriterion("CSPCCAP not in", values, "cspccap");
            return (Criteria) this;
        }

        public Criteria andCspccapBetween(String value1, String value2) {
            addCriterion("CSPCCAP between", value1, value2, "cspccap");
            return (Criteria) this;
        }

        public Criteria andCspccapNotBetween(String value1, String value2) {
            addCriterion("CSPCCAP not between", value1, value2, "cspccap");
            return (Criteria) this;
        }

        public Criteria andCspcvalIsNull() {
            addCriterion("CSPCVAL is null");
            return (Criteria) this;
        }

        public Criteria andCspcvalIsNotNull() {
            addCriterion("CSPCVAL is not null");
            return (Criteria) this;
        }

        public Criteria andCspcvalEqualTo(String value) {
            addCriterion("CSPCVAL =", value, "cspcval");
            return (Criteria) this;
        }

        public Criteria andCspcvalNotEqualTo(String value) {
            addCriterion("CSPCVAL <>", value, "cspcval");
            return (Criteria) this;
        }

        public Criteria andCspcvalGreaterThan(String value) {
            addCriterion("CSPCVAL >", value, "cspcval");
            return (Criteria) this;
        }

        public Criteria andCspcvalGreaterThanOrEqualTo(String value) {
            addCriterion("CSPCVAL >=", value, "cspcval");
            return (Criteria) this;
        }

        public Criteria andCspcvalLessThan(String value) {
            addCriterion("CSPCVAL <", value, "cspcval");
            return (Criteria) this;
        }

        public Criteria andCspcvalLessThanOrEqualTo(String value) {
            addCriterion("CSPCVAL <=", value, "cspcval");
            return (Criteria) this;
        }

        public Criteria andCspcvalLike(String value) {
            addCriterion("CSPCVAL like", value, "cspcval");
            return (Criteria) this;
        }

        public Criteria andCspcvalNotLike(String value) {
            addCriterion("CSPCVAL not like", value, "cspcval");
            return (Criteria) this;
        }

        public Criteria andCspcvalIn(List<String> values) {
            addCriterion("CSPCVAL in", values, "cspcval");
            return (Criteria) this;
        }

        public Criteria andCspcvalNotIn(List<String> values) {
            addCriterion("CSPCVAL not in", values, "cspcval");
            return (Criteria) this;
        }

        public Criteria andCspcvalBetween(String value1, String value2) {
            addCriterion("CSPCVAL between", value1, value2, "cspcval");
            return (Criteria) this;
        }

        public Criteria andCspcvalNotBetween(String value1, String value2) {
            addCriterion("CSPCVAL not between", value1, value2, "cspcval");
            return (Criteria) this;
        }

        public Criteria andFsubsteIsNull() {
            addCriterion("FSUBSTE is null");
            return (Criteria) this;
        }

        public Criteria andFsubsteIsNotNull() {
            addCriterion("FSUBSTE is not null");
            return (Criteria) this;
        }

        public Criteria andFsubsteEqualTo(String value) {
            addCriterion("FSUBSTE =", value, "fsubste");
            return (Criteria) this;
        }

        public Criteria andFsubsteNotEqualTo(String value) {
            addCriterion("FSUBSTE <>", value, "fsubste");
            return (Criteria) this;
        }

        public Criteria andFsubsteGreaterThan(String value) {
            addCriterion("FSUBSTE >", value, "fsubste");
            return (Criteria) this;
        }

        public Criteria andFsubsteGreaterThanOrEqualTo(String value) {
            addCriterion("FSUBSTE >=", value, "fsubste");
            return (Criteria) this;
        }

        public Criteria andFsubsteLessThan(String value) {
            addCriterion("FSUBSTE <", value, "fsubste");
            return (Criteria) this;
        }

        public Criteria andFsubsteLessThanOrEqualTo(String value) {
            addCriterion("FSUBSTE <=", value, "fsubste");
            return (Criteria) this;
        }

        public Criteria andFsubsteLike(String value) {
            addCriterion("FSUBSTE like", value, "fsubste");
            return (Criteria) this;
        }

        public Criteria andFsubsteNotLike(String value) {
            addCriterion("FSUBSTE not like", value, "fsubste");
            return (Criteria) this;
        }

        public Criteria andFsubsteIn(List<String> values) {
            addCriterion("FSUBSTE in", values, "fsubste");
            return (Criteria) this;
        }

        public Criteria andFsubsteNotIn(List<String> values) {
            addCriterion("FSUBSTE not in", values, "fsubste");
            return (Criteria) this;
        }

        public Criteria andFsubsteBetween(String value1, String value2) {
            addCriterion("FSUBSTE between", value1, value2, "fsubste");
            return (Criteria) this;
        }

        public Criteria andFsubsteNotBetween(String value1, String value2) {
            addCriterion("FSUBSTE not between", value1, value2, "fsubste");
            return (Criteria) this;
        }

        public Criteria andCspccafIsNull() {
            addCriterion("CSPCCAF is null");
            return (Criteria) this;
        }

        public Criteria andCspccafIsNotNull() {
            addCriterion("CSPCCAF is not null");
            return (Criteria) this;
        }

        public Criteria andCspccafEqualTo(String value) {
            addCriterion("CSPCCAF =", value, "cspccaf");
            return (Criteria) this;
        }

        public Criteria andCspccafNotEqualTo(String value) {
            addCriterion("CSPCCAF <>", value, "cspccaf");
            return (Criteria) this;
        }

        public Criteria andCspccafGreaterThan(String value) {
            addCriterion("CSPCCAF >", value, "cspccaf");
            return (Criteria) this;
        }

        public Criteria andCspccafGreaterThanOrEqualTo(String value) {
            addCriterion("CSPCCAF >=", value, "cspccaf");
            return (Criteria) this;
        }

        public Criteria andCspccafLessThan(String value) {
            addCriterion("CSPCCAF <", value, "cspccaf");
            return (Criteria) this;
        }

        public Criteria andCspccafLessThanOrEqualTo(String value) {
            addCriterion("CSPCCAF <=", value, "cspccaf");
            return (Criteria) this;
        }

        public Criteria andCspccafLike(String value) {
            addCriterion("CSPCCAF like", value, "cspccaf");
            return (Criteria) this;
        }

        public Criteria andCspccafNotLike(String value) {
            addCriterion("CSPCCAF not like", value, "cspccaf");
            return (Criteria) this;
        }

        public Criteria andCspccafIn(List<String> values) {
            addCriterion("CSPCCAF in", values, "cspccaf");
            return (Criteria) this;
        }

        public Criteria andCspccafNotIn(List<String> values) {
            addCriterion("CSPCCAF not in", values, "cspccaf");
            return (Criteria) this;
        }

        public Criteria andCspccafBetween(String value1, String value2) {
            addCriterion("CSPCCAF between", value1, value2, "cspccaf");
            return (Criteria) this;
        }

        public Criteria andCspccafNotBetween(String value1, String value2) {
            addCriterion("CSPCCAF not between", value1, value2, "cspccaf");
            return (Criteria) this;
        }

        public Criteria andCspcreaIsNull() {
            addCriterion("CSPCREA is null");
            return (Criteria) this;
        }

        public Criteria andCspcreaIsNotNull() {
            addCriterion("CSPCREA is not null");
            return (Criteria) this;
        }

        public Criteria andCspcreaEqualTo(String value) {
            addCriterion("CSPCREA =", value, "cspcrea");
            return (Criteria) this;
        }

        public Criteria andCspcreaNotEqualTo(String value) {
            addCriterion("CSPCREA <>", value, "cspcrea");
            return (Criteria) this;
        }

        public Criteria andCspcreaGreaterThan(String value) {
            addCriterion("CSPCREA >", value, "cspcrea");
            return (Criteria) this;
        }

        public Criteria andCspcreaGreaterThanOrEqualTo(String value) {
            addCriterion("CSPCREA >=", value, "cspcrea");
            return (Criteria) this;
        }

        public Criteria andCspcreaLessThan(String value) {
            addCriterion("CSPCREA <", value, "cspcrea");
            return (Criteria) this;
        }

        public Criteria andCspcreaLessThanOrEqualTo(String value) {
            addCriterion("CSPCREA <=", value, "cspcrea");
            return (Criteria) this;
        }

        public Criteria andCspcreaLike(String value) {
            addCriterion("CSPCREA like", value, "cspcrea");
            return (Criteria) this;
        }

        public Criteria andCspcreaNotLike(String value) {
            addCriterion("CSPCREA not like", value, "cspcrea");
            return (Criteria) this;
        }

        public Criteria andCspcreaIn(List<String> values) {
            addCriterion("CSPCREA in", values, "cspcrea");
            return (Criteria) this;
        }

        public Criteria andCspcreaNotIn(List<String> values) {
            addCriterion("CSPCREA not in", values, "cspcrea");
            return (Criteria) this;
        }

        public Criteria andCspcreaBetween(String value1, String value2) {
            addCriterion("CSPCREA between", value1, value2, "cspcrea");
            return (Criteria) this;
        }

        public Criteria andCspcreaNotBetween(String value1, String value2) {
            addCriterion("CSPCREA not between", value1, value2, "cspcrea");
            return (Criteria) this;
        }

        public Criteria andDperperIsNull() {
            addCriterion("DPERPER is null");
            return (Criteria) this;
        }

        public Criteria andDperperIsNotNull() {
            addCriterion("DPERPER is not null");
            return (Criteria) this;
        }

        public Criteria andDperperEqualTo(String value) {
            addCriterion("DPERPER =", value, "dperper");
            return (Criteria) this;
        }

        public Criteria andDperperNotEqualTo(String value) {
            addCriterion("DPERPER <>", value, "dperper");
            return (Criteria) this;
        }

        public Criteria andDperperGreaterThan(String value) {
            addCriterion("DPERPER >", value, "dperper");
            return (Criteria) this;
        }

        public Criteria andDperperGreaterThanOrEqualTo(String value) {
            addCriterion("DPERPER >=", value, "dperper");
            return (Criteria) this;
        }

        public Criteria andDperperLessThan(String value) {
            addCriterion("DPERPER <", value, "dperper");
            return (Criteria) this;
        }

        public Criteria andDperperLessThanOrEqualTo(String value) {
            addCriterion("DPERPER <=", value, "dperper");
            return (Criteria) this;
        }

        public Criteria andDperperLike(String value) {
            addCriterion("DPERPER like", value, "dperper");
            return (Criteria) this;
        }

        public Criteria andDperperNotLike(String value) {
            addCriterion("DPERPER not like", value, "dperper");
            return (Criteria) this;
        }

        public Criteria andDperperIn(List<String> values) {
            addCriterion("DPERPER in", values, "dperper");
            return (Criteria) this;
        }

        public Criteria andDperperNotIn(List<String> values) {
            addCriterion("DPERPER not in", values, "dperper");
            return (Criteria) this;
        }

        public Criteria andDperperBetween(String value1, String value2) {
            addCriterion("DPERPER between", value1, value2, "dperper");
            return (Criteria) this;
        }

        public Criteria andDperperNotBetween(String value1, String value2) {
            addCriterion("DPERPER not between", value1, value2, "dperper");
            return (Criteria) this;
        }

        public Criteria andDspcautIsNull() {
            addCriterion("DSPCAUT is null");
            return (Criteria) this;
        }

        public Criteria andDspcautIsNotNull() {
            addCriterion("DSPCAUT is not null");
            return (Criteria) this;
        }

        public Criteria andDspcautEqualTo(Date value) {
            addCriterion("DSPCAUT =", value, "dspcaut");
            return (Criteria) this;
        }

        public Criteria andDspcautNotEqualTo(Date value) {
            addCriterion("DSPCAUT <>", value, "dspcaut");
            return (Criteria) this;
        }

        public Criteria andDspcautGreaterThan(Date value) {
            addCriterion("DSPCAUT >", value, "dspcaut");
            return (Criteria) this;
        }

        public Criteria andDspcautGreaterThanOrEqualTo(Date value) {
            addCriterion("DSPCAUT >=", value, "dspcaut");
            return (Criteria) this;
        }

        public Criteria andDspcautLessThan(Date value) {
            addCriterion("DSPCAUT <", value, "dspcaut");
            return (Criteria) this;
        }

        public Criteria andDspcautLessThanOrEqualTo(Date value) {
            addCriterion("DSPCAUT <=", value, "dspcaut");
            return (Criteria) this;
        }

        public Criteria andDspcautIn(List<Date> values) {
            addCriterion("DSPCAUT in", values, "dspcaut");
            return (Criteria) this;
        }

        public Criteria andDspcautNotIn(List<Date> values) {
            addCriterion("DSPCAUT not in", values, "dspcaut");
            return (Criteria) this;
        }

        public Criteria andDspcautBetween(Date value1, Date value2) {
            addCriterion("DSPCAUT between", value1, value2, "dspcaut");
            return (Criteria) this;
        }

        public Criteria andDspcautNotBetween(Date value1, Date value2) {
            addCriterion("DSPCAUT not between", value1, value2, "dspcaut");
            return (Criteria) this;
        }

        public Criteria andSspcauuIsNull() {
            addCriterion("SSPCAUU is null");
            return (Criteria) this;
        }

        public Criteria andSspcauuIsNotNull() {
            addCriterion("SSPCAUU is not null");
            return (Criteria) this;
        }

        public Criteria andSspcauuEqualTo(String value) {
            addCriterion("SSPCAUU =", value, "sspcauu");
            return (Criteria) this;
        }

        public Criteria andSspcauuNotEqualTo(String value) {
            addCriterion("SSPCAUU <>", value, "sspcauu");
            return (Criteria) this;
        }

        public Criteria andSspcauuGreaterThan(String value) {
            addCriterion("SSPCAUU >", value, "sspcauu");
            return (Criteria) this;
        }

        public Criteria andSspcauuGreaterThanOrEqualTo(String value) {
            addCriterion("SSPCAUU >=", value, "sspcauu");
            return (Criteria) this;
        }

        public Criteria andSspcauuLessThan(String value) {
            addCriterion("SSPCAUU <", value, "sspcauu");
            return (Criteria) this;
        }

        public Criteria andSspcauuLessThanOrEqualTo(String value) {
            addCriterion("SSPCAUU <=", value, "sspcauu");
            return (Criteria) this;
        }

        public Criteria andSspcauuLike(String value) {
            addCriterion("SSPCAUU like", value, "sspcauu");
            return (Criteria) this;
        }

        public Criteria andSspcauuNotLike(String value) {
            addCriterion("SSPCAUU not like", value, "sspcauu");
            return (Criteria) this;
        }

        public Criteria andSspcauuIn(List<String> values) {
            addCriterion("SSPCAUU in", values, "sspcauu");
            return (Criteria) this;
        }

        public Criteria andSspcauuNotIn(List<String> values) {
            addCriterion("SSPCAUU not in", values, "sspcauu");
            return (Criteria) this;
        }

        public Criteria andSspcauuBetween(String value1, String value2) {
            addCriterion("SSPCAUU between", value1, value2, "sspcauu");
            return (Criteria) this;
        }

        public Criteria andSspcauuNotBetween(String value1, String value2) {
            addCriterion("SSPCAUU not between", value1, value2, "sspcauu");
            return (Criteria) this;
        }

        public Criteria andSspcaupIsNull() {
            addCriterion("SSPCAUP is null");
            return (Criteria) this;
        }

        public Criteria andSspcaupIsNotNull() {
            addCriterion("SSPCAUP is not null");
            return (Criteria) this;
        }

        public Criteria andSspcaupEqualTo(String value) {
            addCriterion("SSPCAUP =", value, "sspcaup");
            return (Criteria) this;
        }

        public Criteria andSspcaupNotEqualTo(String value) {
            addCriterion("SSPCAUP <>", value, "sspcaup");
            return (Criteria) this;
        }

        public Criteria andSspcaupGreaterThan(String value) {
            addCriterion("SSPCAUP >", value, "sspcaup");
            return (Criteria) this;
        }

        public Criteria andSspcaupGreaterThanOrEqualTo(String value) {
            addCriterion("SSPCAUP >=", value, "sspcaup");
            return (Criteria) this;
        }

        public Criteria andSspcaupLessThan(String value) {
            addCriterion("SSPCAUP <", value, "sspcaup");
            return (Criteria) this;
        }

        public Criteria andSspcaupLessThanOrEqualTo(String value) {
            addCriterion("SSPCAUP <=", value, "sspcaup");
            return (Criteria) this;
        }

        public Criteria andSspcaupLike(String value) {
            addCriterion("SSPCAUP like", value, "sspcaup");
            return (Criteria) this;
        }

        public Criteria andSspcaupNotLike(String value) {
            addCriterion("SSPCAUP not like", value, "sspcaup");
            return (Criteria) this;
        }

        public Criteria andSspcaupIn(List<String> values) {
            addCriterion("SSPCAUP in", values, "sspcaup");
            return (Criteria) this;
        }

        public Criteria andSspcaupNotIn(List<String> values) {
            addCriterion("SSPCAUP not in", values, "sspcaup");
            return (Criteria) this;
        }

        public Criteria andSspcaupBetween(String value1, String value2) {
            addCriterion("SSPCAUP between", value1, value2, "sspcaup");
            return (Criteria) this;
        }

        public Criteria andSspcaupNotBetween(String value1, String value2) {
            addCriterion("SSPCAUP not between", value1, value2, "sspcaup");
            return (Criteria) this;
        }

        public Criteria andIspcmchIsNull() {
            addCriterion("ISPCMCH is null");
            return (Criteria) this;
        }

        public Criteria andIspcmchIsNotNull() {
            addCriterion("ISPCMCH is not null");
            return (Criteria) this;
        }

        public Criteria andIspcmchEqualTo(String value) {
            addCriterion("ISPCMCH =", value, "ispcmch");
            return (Criteria) this;
        }

        public Criteria andIspcmchNotEqualTo(String value) {
            addCriterion("ISPCMCH <>", value, "ispcmch");
            return (Criteria) this;
        }

        public Criteria andIspcmchGreaterThan(String value) {
            addCriterion("ISPCMCH >", value, "ispcmch");
            return (Criteria) this;
        }

        public Criteria andIspcmchGreaterThanOrEqualTo(String value) {
            addCriterion("ISPCMCH >=", value, "ispcmch");
            return (Criteria) this;
        }

        public Criteria andIspcmchLessThan(String value) {
            addCriterion("ISPCMCH <", value, "ispcmch");
            return (Criteria) this;
        }

        public Criteria andIspcmchLessThanOrEqualTo(String value) {
            addCriterion("ISPCMCH <=", value, "ispcmch");
            return (Criteria) this;
        }

        public Criteria andIspcmchLike(String value) {
            addCriterion("ISPCMCH like", value, "ispcmch");
            return (Criteria) this;
        }

        public Criteria andIspcmchNotLike(String value) {
            addCriterion("ISPCMCH not like", value, "ispcmch");
            return (Criteria) this;
        }

        public Criteria andIspcmchIn(List<String> values) {
            addCriterion("ISPCMCH in", values, "ispcmch");
            return (Criteria) this;
        }

        public Criteria andIspcmchNotIn(List<String> values) {
            addCriterion("ISPCMCH not in", values, "ispcmch");
            return (Criteria) this;
        }

        public Criteria andIspcmchBetween(String value1, String value2) {
            addCriterion("ISPCMCH between", value1, value2, "ispcmch");
            return (Criteria) this;
        }

        public Criteria andIspcmchNotBetween(String value1, String value2) {
            addCriterion("ISPCMCH not between", value1, value2, "ispcmch");
            return (Criteria) this;
        }

        public Criteria andFspcsnsIsNull() {
            addCriterion("FSPCSNS is null");
            return (Criteria) this;
        }

        public Criteria andFspcsnsIsNotNull() {
            addCriterion("FSPCSNS is not null");
            return (Criteria) this;
        }

        public Criteria andFspcsnsEqualTo(String value) {
            addCriterion("FSPCSNS =", value, "fspcsns");
            return (Criteria) this;
        }

        public Criteria andFspcsnsNotEqualTo(String value) {
            addCriterion("FSPCSNS <>", value, "fspcsns");
            return (Criteria) this;
        }

        public Criteria andFspcsnsGreaterThan(String value) {
            addCriterion("FSPCSNS >", value, "fspcsns");
            return (Criteria) this;
        }

        public Criteria andFspcsnsGreaterThanOrEqualTo(String value) {
            addCriterion("FSPCSNS >=", value, "fspcsns");
            return (Criteria) this;
        }

        public Criteria andFspcsnsLessThan(String value) {
            addCriterion("FSPCSNS <", value, "fspcsns");
            return (Criteria) this;
        }

        public Criteria andFspcsnsLessThanOrEqualTo(String value) {
            addCriterion("FSPCSNS <=", value, "fspcsns");
            return (Criteria) this;
        }

        public Criteria andFspcsnsLike(String value) {
            addCriterion("FSPCSNS like", value, "fspcsns");
            return (Criteria) this;
        }

        public Criteria andFspcsnsNotLike(String value) {
            addCriterion("FSPCSNS not like", value, "fspcsns");
            return (Criteria) this;
        }

        public Criteria andFspcsnsIn(List<String> values) {
            addCriterion("FSPCSNS in", values, "fspcsns");
            return (Criteria) this;
        }

        public Criteria andFspcsnsNotIn(List<String> values) {
            addCriterion("FSPCSNS not in", values, "fspcsns");
            return (Criteria) this;
        }

        public Criteria andFspcsnsBetween(String value1, String value2) {
            addCriterion("FSPCSNS between", value1, value2, "fspcsns");
            return (Criteria) this;
        }

        public Criteria andFspcsnsNotBetween(String value1, String value2) {
            addCriterion("FSPCSNS not between", value1, value2, "fspcsns");
            return (Criteria) this;
        }

        public Criteria andFspcrepIsNull() {
            addCriterion("FSPCREP is null");
            return (Criteria) this;
        }

        public Criteria andFspcrepIsNotNull() {
            addCriterion("FSPCREP is not null");
            return (Criteria) this;
        }

        public Criteria andFspcrepEqualTo(String value) {
            addCriterion("FSPCREP =", value, "fspcrep");
            return (Criteria) this;
        }

        public Criteria andFspcrepNotEqualTo(String value) {
            addCriterion("FSPCREP <>", value, "fspcrep");
            return (Criteria) this;
        }

        public Criteria andFspcrepGreaterThan(String value) {
            addCriterion("FSPCREP >", value, "fspcrep");
            return (Criteria) this;
        }

        public Criteria andFspcrepGreaterThanOrEqualTo(String value) {
            addCriterion("FSPCREP >=", value, "fspcrep");
            return (Criteria) this;
        }

        public Criteria andFspcrepLessThan(String value) {
            addCriterion("FSPCREP <", value, "fspcrep");
            return (Criteria) this;
        }

        public Criteria andFspcrepLessThanOrEqualTo(String value) {
            addCriterion("FSPCREP <=", value, "fspcrep");
            return (Criteria) this;
        }

        public Criteria andFspcrepLike(String value) {
            addCriterion("FSPCREP like", value, "fspcrep");
            return (Criteria) this;
        }

        public Criteria andFspcrepNotLike(String value) {
            addCriterion("FSPCREP not like", value, "fspcrep");
            return (Criteria) this;
        }

        public Criteria andFspcrepIn(List<String> values) {
            addCriterion("FSPCREP in", values, "fspcrep");
            return (Criteria) this;
        }

        public Criteria andFspcrepNotIn(List<String> values) {
            addCriterion("FSPCREP not in", values, "fspcrep");
            return (Criteria) this;
        }

        public Criteria andFspcrepBetween(String value1, String value2) {
            addCriterion("FSPCREP between", value1, value2, "fspcrep");
            return (Criteria) this;
        }

        public Criteria andFspcrepNotBetween(String value1, String value2) {
            addCriterion("FSPCREP not between", value1, value2, "fspcrep");
            return (Criteria) this;
        }

        public Criteria andFspcemaIsNull() {
            addCriterion("FSPCEMA is null");
            return (Criteria) this;
        }

        public Criteria andFspcemaIsNotNull() {
            addCriterion("FSPCEMA is not null");
            return (Criteria) this;
        }

        public Criteria andFspcemaEqualTo(String value) {
            addCriterion("FSPCEMA =", value, "fspcema");
            return (Criteria) this;
        }

        public Criteria andFspcemaNotEqualTo(String value) {
            addCriterion("FSPCEMA <>", value, "fspcema");
            return (Criteria) this;
        }

        public Criteria andFspcemaGreaterThan(String value) {
            addCriterion("FSPCEMA >", value, "fspcema");
            return (Criteria) this;
        }

        public Criteria andFspcemaGreaterThanOrEqualTo(String value) {
            addCriterion("FSPCEMA >=", value, "fspcema");
            return (Criteria) this;
        }

        public Criteria andFspcemaLessThan(String value) {
            addCriterion("FSPCEMA <", value, "fspcema");
            return (Criteria) this;
        }

        public Criteria andFspcemaLessThanOrEqualTo(String value) {
            addCriterion("FSPCEMA <=", value, "fspcema");
            return (Criteria) this;
        }

        public Criteria andFspcemaLike(String value) {
            addCriterion("FSPCEMA like", value, "fspcema");
            return (Criteria) this;
        }

        public Criteria andFspcemaNotLike(String value) {
            addCriterion("FSPCEMA not like", value, "fspcema");
            return (Criteria) this;
        }

        public Criteria andFspcemaIn(List<String> values) {
            addCriterion("FSPCEMA in", values, "fspcema");
            return (Criteria) this;
        }

        public Criteria andFspcemaNotIn(List<String> values) {
            addCriterion("FSPCEMA not in", values, "fspcema");
            return (Criteria) this;
        }

        public Criteria andFspcemaBetween(String value1, String value2) {
            addCriterion("FSPCEMA between", value1, value2, "fspcema");
            return (Criteria) this;
        }

        public Criteria andFspcemaNotBetween(String value1, String value2) {
            addCriterion("FSPCEMA not between", value1, value2, "fspcema");
            return (Criteria) this;
        }

        public Criteria andIspccusIsNull() {
            addCriterion("ISPCCUS is null");
            return (Criteria) this;
        }

        public Criteria andIspccusIsNotNull() {
            addCriterion("ISPCCUS is not null");
            return (Criteria) this;
        }

        public Criteria andIspccusEqualTo(String value) {
            addCriterion("ISPCCUS =", value, "ispccus");
            return (Criteria) this;
        }

        public Criteria andIspccusNotEqualTo(String value) {
            addCriterion("ISPCCUS <>", value, "ispccus");
            return (Criteria) this;
        }

        public Criteria andIspccusGreaterThan(String value) {
            addCriterion("ISPCCUS >", value, "ispccus");
            return (Criteria) this;
        }

        public Criteria andIspccusGreaterThanOrEqualTo(String value) {
            addCriterion("ISPCCUS >=", value, "ispccus");
            return (Criteria) this;
        }

        public Criteria andIspccusLessThan(String value) {
            addCriterion("ISPCCUS <", value, "ispccus");
            return (Criteria) this;
        }

        public Criteria andIspccusLessThanOrEqualTo(String value) {
            addCriterion("ISPCCUS <=", value, "ispccus");
            return (Criteria) this;
        }

        public Criteria andIspccusLike(String value) {
            addCriterion("ISPCCUS like", value, "ispccus");
            return (Criteria) this;
        }

        public Criteria andIspccusNotLike(String value) {
            addCriterion("ISPCCUS not like", value, "ispccus");
            return (Criteria) this;
        }

        public Criteria andIspccusIn(List<String> values) {
            addCriterion("ISPCCUS in", values, "ispccus");
            return (Criteria) this;
        }

        public Criteria andIspccusNotIn(List<String> values) {
            addCriterion("ISPCCUS not in", values, "ispccus");
            return (Criteria) this;
        }

        public Criteria andIspccusBetween(String value1, String value2) {
            addCriterion("ISPCCUS between", value1, value2, "ispccus");
            return (Criteria) this;
        }

        public Criteria andIspccusNotBetween(String value1, String value2) {
            addCriterion("ISPCCUS not between", value1, value2, "ispccus");
            return (Criteria) this;
        }

        public Criteria andIspcctyIsNull() {
            addCriterion("ISPCCTY is null");
            return (Criteria) this;
        }

        public Criteria andIspcctyIsNotNull() {
            addCriterion("ISPCCTY is not null");
            return (Criteria) this;
        }

        public Criteria andIspcctyEqualTo(String value) {
            addCriterion("ISPCCTY =", value, "ispccty");
            return (Criteria) this;
        }

        public Criteria andIspcctyNotEqualTo(String value) {
            addCriterion("ISPCCTY <>", value, "ispccty");
            return (Criteria) this;
        }

        public Criteria andIspcctyGreaterThan(String value) {
            addCriterion("ISPCCTY >", value, "ispccty");
            return (Criteria) this;
        }

        public Criteria andIspcctyGreaterThanOrEqualTo(String value) {
            addCriterion("ISPCCTY >=", value, "ispccty");
            return (Criteria) this;
        }

        public Criteria andIspcctyLessThan(String value) {
            addCriterion("ISPCCTY <", value, "ispccty");
            return (Criteria) this;
        }

        public Criteria andIspcctyLessThanOrEqualTo(String value) {
            addCriterion("ISPCCTY <=", value, "ispccty");
            return (Criteria) this;
        }

        public Criteria andIspcctyLike(String value) {
            addCriterion("ISPCCTY like", value, "ispccty");
            return (Criteria) this;
        }

        public Criteria andIspcctyNotLike(String value) {
            addCriterion("ISPCCTY not like", value, "ispccty");
            return (Criteria) this;
        }

        public Criteria andIspcctyIn(List<String> values) {
            addCriterion("ISPCCTY in", values, "ispccty");
            return (Criteria) this;
        }

        public Criteria andIspcctyNotIn(List<String> values) {
            addCriterion("ISPCCTY not in", values, "ispccty");
            return (Criteria) this;
        }

        public Criteria andIspcctyBetween(String value1, String value2) {
            addCriterion("ISPCCTY between", value1, value2, "ispccty");
            return (Criteria) this;
        }

        public Criteria andIspcctyNotBetween(String value1, String value2) {
            addCriterion("ISPCCTY not between", value1, value2, "ispccty");
            return (Criteria) this;
        }

        public Criteria andQspccouIsNull() {
            addCriterion("QSPCCOU is null");
            return (Criteria) this;
        }

        public Criteria andQspccouIsNotNull() {
            addCriterion("QSPCCOU is not null");
            return (Criteria) this;
        }

        public Criteria andQspccouEqualTo(Integer value) {
            addCriterion("QSPCCOU =", value, "qspccou");
            return (Criteria) this;
        }

        public Criteria andQspccouNotEqualTo(Integer value) {
            addCriterion("QSPCCOU <>", value, "qspccou");
            return (Criteria) this;
        }

        public Criteria andQspccouGreaterThan(Integer value) {
            addCriterion("QSPCCOU >", value, "qspccou");
            return (Criteria) this;
        }

        public Criteria andQspccouGreaterThanOrEqualTo(Integer value) {
            addCriterion("QSPCCOU >=", value, "qspccou");
            return (Criteria) this;
        }

        public Criteria andQspccouLessThan(Integer value) {
            addCriterion("QSPCCOU <", value, "qspccou");
            return (Criteria) this;
        }

        public Criteria andQspccouLessThanOrEqualTo(Integer value) {
            addCriterion("QSPCCOU <=", value, "qspccou");
            return (Criteria) this;
        }

        public Criteria andQspccouIn(List<Integer> values) {
            addCriterion("QSPCCOU in", values, "qspccou");
            return (Criteria) this;
        }

        public Criteria andQspccouNotIn(List<Integer> values) {
            addCriterion("QSPCCOU not in", values, "qspccou");
            return (Criteria) this;
        }

        public Criteria andQspccouBetween(Integer value1, Integer value2) {
            addCriterion("QSPCCOU between", value1, value2, "qspccou");
            return (Criteria) this;
        }

        public Criteria andQspccouNotBetween(Integer value1, Integer value2) {
            addCriterion("QSPCCOU not between", value1, value2, "qspccou");
            return (Criteria) this;
        }

        public Criteria andQspcpmcIsNull() {
            addCriterion("QSPCPMC is null");
            return (Criteria) this;
        }

        public Criteria andQspcpmcIsNotNull() {
            addCriterion("QSPCPMC is not null");
            return (Criteria) this;
        }

        public Criteria andQspcpmcEqualTo(Integer value) {
            addCriterion("QSPCPMC =", value, "qspcpmc");
            return (Criteria) this;
        }

        public Criteria andQspcpmcNotEqualTo(Integer value) {
            addCriterion("QSPCPMC <>", value, "qspcpmc");
            return (Criteria) this;
        }

        public Criteria andQspcpmcGreaterThan(Integer value) {
            addCriterion("QSPCPMC >", value, "qspcpmc");
            return (Criteria) this;
        }

        public Criteria andQspcpmcGreaterThanOrEqualTo(Integer value) {
            addCriterion("QSPCPMC >=", value, "qspcpmc");
            return (Criteria) this;
        }

        public Criteria andQspcpmcLessThan(Integer value) {
            addCriterion("QSPCPMC <", value, "qspcpmc");
            return (Criteria) this;
        }

        public Criteria andQspcpmcLessThanOrEqualTo(Integer value) {
            addCriterion("QSPCPMC <=", value, "qspcpmc");
            return (Criteria) this;
        }

        public Criteria andQspcpmcIn(List<Integer> values) {
            addCriterion("QSPCPMC in", values, "qspcpmc");
            return (Criteria) this;
        }

        public Criteria andQspcpmcNotIn(List<Integer> values) {
            addCriterion("QSPCPMC not in", values, "qspcpmc");
            return (Criteria) this;
        }

        public Criteria andQspcpmcBetween(Integer value1, Integer value2) {
            addCriterion("QSPCPMC between", value1, value2, "qspcpmc");
            return (Criteria) this;
        }

        public Criteria andQspcpmcNotBetween(Integer value1, Integer value2) {
            addCriterion("QSPCPMC not between", value1, value2, "qspcpmc");
            return (Criteria) this;
        }

        public Criteria andQspctmcIsNull() {
            addCriterion("QSPCTMC is null");
            return (Criteria) this;
        }

        public Criteria andQspctmcIsNotNull() {
            addCriterion("QSPCTMC is not null");
            return (Criteria) this;
        }

        public Criteria andQspctmcEqualTo(Integer value) {
            addCriterion("QSPCTMC =", value, "qspctmc");
            return (Criteria) this;
        }

        public Criteria andQspctmcNotEqualTo(Integer value) {
            addCriterion("QSPCTMC <>", value, "qspctmc");
            return (Criteria) this;
        }

        public Criteria andQspctmcGreaterThan(Integer value) {
            addCriterion("QSPCTMC >", value, "qspctmc");
            return (Criteria) this;
        }

        public Criteria andQspctmcGreaterThanOrEqualTo(Integer value) {
            addCriterion("QSPCTMC >=", value, "qspctmc");
            return (Criteria) this;
        }

        public Criteria andQspctmcLessThan(Integer value) {
            addCriterion("QSPCTMC <", value, "qspctmc");
            return (Criteria) this;
        }

        public Criteria andQspctmcLessThanOrEqualTo(Integer value) {
            addCriterion("QSPCTMC <=", value, "qspctmc");
            return (Criteria) this;
        }

        public Criteria andQspctmcIn(List<Integer> values) {
            addCriterion("QSPCTMC in", values, "qspctmc");
            return (Criteria) this;
        }

        public Criteria andQspctmcNotIn(List<Integer> values) {
            addCriterion("QSPCTMC not in", values, "qspctmc");
            return (Criteria) this;
        }

        public Criteria andQspctmcBetween(Integer value1, Integer value2) {
            addCriterion("QSPCTMC between", value1, value2, "qspctmc");
            return (Criteria) this;
        }

        public Criteria andQspctmcNotBetween(Integer value1, Integer value2) {
            addCriterion("QSPCTMC not between", value1, value2, "qspctmc");
            return (Criteria) this;
        }

        public Criteria andCspcicaIsNull() {
            addCriterion("CSPCICA is null");
            return (Criteria) this;
        }

        public Criteria andCspcicaIsNotNull() {
            addCriterion("CSPCICA is not null");
            return (Criteria) this;
        }

        public Criteria andCspcicaEqualTo(String value) {
            addCriterion("CSPCICA =", value, "cspcica");
            return (Criteria) this;
        }

        public Criteria andCspcicaNotEqualTo(String value) {
            addCriterion("CSPCICA <>", value, "cspcica");
            return (Criteria) this;
        }

        public Criteria andCspcicaGreaterThan(String value) {
            addCriterion("CSPCICA >", value, "cspcica");
            return (Criteria) this;
        }

        public Criteria andCspcicaGreaterThanOrEqualTo(String value) {
            addCriterion("CSPCICA >=", value, "cspcica");
            return (Criteria) this;
        }

        public Criteria andCspcicaLessThan(String value) {
            addCriterion("CSPCICA <", value, "cspcica");
            return (Criteria) this;
        }

        public Criteria andCspcicaLessThanOrEqualTo(String value) {
            addCriterion("CSPCICA <=", value, "cspcica");
            return (Criteria) this;
        }

        public Criteria andCspcicaLike(String value) {
            addCriterion("CSPCICA like", value, "cspcica");
            return (Criteria) this;
        }

        public Criteria andCspcicaNotLike(String value) {
            addCriterion("CSPCICA not like", value, "cspcica");
            return (Criteria) this;
        }

        public Criteria andCspcicaIn(List<String> values) {
            addCriterion("CSPCICA in", values, "cspcica");
            return (Criteria) this;
        }

        public Criteria andCspcicaNotIn(List<String> values) {
            addCriterion("CSPCICA not in", values, "cspcica");
            return (Criteria) this;
        }

        public Criteria andCspcicaBetween(String value1, String value2) {
            addCriterion("CSPCICA between", value1, value2, "cspcica");
            return (Criteria) this;
        }

        public Criteria andCspcicaNotBetween(String value1, String value2) {
            addCriterion("CSPCICA not between", value1, value2, "cspcica");
            return (Criteria) this;
        }

        public Criteria andCspciplIsNull() {
            addCriterion("CSPCIPL is null");
            return (Criteria) this;
        }

        public Criteria andCspciplIsNotNull() {
            addCriterion("CSPCIPL is not null");
            return (Criteria) this;
        }

        public Criteria andCspciplEqualTo(String value) {
            addCriterion("CSPCIPL =", value, "cspcipl");
            return (Criteria) this;
        }

        public Criteria andCspciplNotEqualTo(String value) {
            addCriterion("CSPCIPL <>", value, "cspcipl");
            return (Criteria) this;
        }

        public Criteria andCspciplGreaterThan(String value) {
            addCriterion("CSPCIPL >", value, "cspcipl");
            return (Criteria) this;
        }

        public Criteria andCspciplGreaterThanOrEqualTo(String value) {
            addCriterion("CSPCIPL >=", value, "cspcipl");
            return (Criteria) this;
        }

        public Criteria andCspciplLessThan(String value) {
            addCriterion("CSPCIPL <", value, "cspcipl");
            return (Criteria) this;
        }

        public Criteria andCspciplLessThanOrEqualTo(String value) {
            addCriterion("CSPCIPL <=", value, "cspcipl");
            return (Criteria) this;
        }

        public Criteria andCspciplLike(String value) {
            addCriterion("CSPCIPL like", value, "cspcipl");
            return (Criteria) this;
        }

        public Criteria andCspciplNotLike(String value) {
            addCriterion("CSPCIPL not like", value, "cspcipl");
            return (Criteria) this;
        }

        public Criteria andCspciplIn(List<String> values) {
            addCriterion("CSPCIPL in", values, "cspcipl");
            return (Criteria) this;
        }

        public Criteria andCspciplNotIn(List<String> values) {
            addCriterion("CSPCIPL not in", values, "cspcipl");
            return (Criteria) this;
        }

        public Criteria andCspciplBetween(String value1, String value2) {
            addCriterion("CSPCIPL between", value1, value2, "cspcipl");
            return (Criteria) this;
        }

        public Criteria andCspciplNotBetween(String value1, String value2) {
            addCriterion("CSPCIPL not between", value1, value2, "cspcipl");
            return (Criteria) this;
        }

        public Criteria andIspccnmIsNull() {
            addCriterion("ISPCCNM is null");
            return (Criteria) this;
        }

        public Criteria andIspccnmIsNotNull() {
            addCriterion("ISPCCNM is not null");
            return (Criteria) this;
        }

        public Criteria andIspccnmEqualTo(String value) {
            addCriterion("ISPCCNM =", value, "ispccnm");
            return (Criteria) this;
        }

        public Criteria andIspccnmNotEqualTo(String value) {
            addCriterion("ISPCCNM <>", value, "ispccnm");
            return (Criteria) this;
        }

        public Criteria andIspccnmGreaterThan(String value) {
            addCriterion("ISPCCNM >", value, "ispccnm");
            return (Criteria) this;
        }

        public Criteria andIspccnmGreaterThanOrEqualTo(String value) {
            addCriterion("ISPCCNM >=", value, "ispccnm");
            return (Criteria) this;
        }

        public Criteria andIspccnmLessThan(String value) {
            addCriterion("ISPCCNM <", value, "ispccnm");
            return (Criteria) this;
        }

        public Criteria andIspccnmLessThanOrEqualTo(String value) {
            addCriterion("ISPCCNM <=", value, "ispccnm");
            return (Criteria) this;
        }

        public Criteria andIspccnmLike(String value) {
            addCriterion("ISPCCNM like", value, "ispccnm");
            return (Criteria) this;
        }

        public Criteria andIspccnmNotLike(String value) {
            addCriterion("ISPCCNM not like", value, "ispccnm");
            return (Criteria) this;
        }

        public Criteria andIspccnmIn(List<String> values) {
            addCriterion("ISPCCNM in", values, "ispccnm");
            return (Criteria) this;
        }

        public Criteria andIspccnmNotIn(List<String> values) {
            addCriterion("ISPCCNM not in", values, "ispccnm");
            return (Criteria) this;
        }

        public Criteria andIspccnmBetween(String value1, String value2) {
            addCriterion("ISPCCNM between", value1, value2, "ispccnm");
            return (Criteria) this;
        }

        public Criteria andIspccnmNotBetween(String value1, String value2) {
            addCriterion("ISPCCNM not between", value1, value2, "ispccnm");
            return (Criteria) this;
        }

        public Criteria andCspctypIsNull() {
            addCriterion("CSPCTYP is null");
            return (Criteria) this;
        }

        public Criteria andCspctypIsNotNull() {
            addCriterion("CSPCTYP is not null");
            return (Criteria) this;
        }

        public Criteria andCspctypEqualTo(String value) {
            addCriterion("CSPCTYP =", value, "cspctyp");
            return (Criteria) this;
        }

        public Criteria andCspctypNotEqualTo(String value) {
            addCriterion("CSPCTYP <>", value, "cspctyp");
            return (Criteria) this;
        }

        public Criteria andCspctypGreaterThan(String value) {
            addCriterion("CSPCTYP >", value, "cspctyp");
            return (Criteria) this;
        }

        public Criteria andCspctypGreaterThanOrEqualTo(String value) {
            addCriterion("CSPCTYP >=", value, "cspctyp");
            return (Criteria) this;
        }

        public Criteria andCspctypLessThan(String value) {
            addCriterion("CSPCTYP <", value, "cspctyp");
            return (Criteria) this;
        }

        public Criteria andCspctypLessThanOrEqualTo(String value) {
            addCriterion("CSPCTYP <=", value, "cspctyp");
            return (Criteria) this;
        }

        public Criteria andCspctypLike(String value) {
            addCriterion("CSPCTYP like", value, "cspctyp");
            return (Criteria) this;
        }

        public Criteria andCspctypNotLike(String value) {
            addCriterion("CSPCTYP not like", value, "cspctyp");
            return (Criteria) this;
        }

        public Criteria andCspctypIn(List<String> values) {
            addCriterion("CSPCTYP in", values, "cspctyp");
            return (Criteria) this;
        }

        public Criteria andCspctypNotIn(List<String> values) {
            addCriterion("CSPCTYP not in", values, "cspctyp");
            return (Criteria) this;
        }

        public Criteria andCspctypBetween(String value1, String value2) {
            addCriterion("CSPCTYP between", value1, value2, "cspctyp");
            return (Criteria) this;
        }

        public Criteria andCspctypNotBetween(String value1, String value2) {
            addCriterion("CSPCTYP not between", value1, value2, "cspctyp");
            return (Criteria) this;
        }

        public Criteria andCspcremIsNull() {
            addCriterion("CSPCREM is null");
            return (Criteria) this;
        }

        public Criteria andCspcremIsNotNull() {
            addCriterion("CSPCREM is not null");
            return (Criteria) this;
        }

        public Criteria andCspcremEqualTo(String value) {
            addCriterion("CSPCREM =", value, "cspcrem");
            return (Criteria) this;
        }

        public Criteria andCspcremNotEqualTo(String value) {
            addCriterion("CSPCREM <>", value, "cspcrem");
            return (Criteria) this;
        }

        public Criteria andCspcremGreaterThan(String value) {
            addCriterion("CSPCREM >", value, "cspcrem");
            return (Criteria) this;
        }

        public Criteria andCspcremGreaterThanOrEqualTo(String value) {
            addCriterion("CSPCREM >=", value, "cspcrem");
            return (Criteria) this;
        }

        public Criteria andCspcremLessThan(String value) {
            addCriterion("CSPCREM <", value, "cspcrem");
            return (Criteria) this;
        }

        public Criteria andCspcremLessThanOrEqualTo(String value) {
            addCriterion("CSPCREM <=", value, "cspcrem");
            return (Criteria) this;
        }

        public Criteria andCspcremLike(String value) {
            addCriterion("CSPCREM like", value, "cspcrem");
            return (Criteria) this;
        }

        public Criteria andCspcremNotLike(String value) {
            addCriterion("CSPCREM not like", value, "cspcrem");
            return (Criteria) this;
        }

        public Criteria andCspcremIn(List<String> values) {
            addCriterion("CSPCREM in", values, "cspcrem");
            return (Criteria) this;
        }

        public Criteria andCspcremNotIn(List<String> values) {
            addCriterion("CSPCREM not in", values, "cspcrem");
            return (Criteria) this;
        }

        public Criteria andCspcremBetween(String value1, String value2) {
            addCriterion("CSPCREM between", value1, value2, "cspcrem");
            return (Criteria) this;
        }

        public Criteria andCspcremNotBetween(String value1, String value2) {
            addCriterion("CSPCREM not between", value1, value2, "cspcrem");
            return (Criteria) this;
        }

        public Criteria andFspcvalIsNull() {
            addCriterion("FSPCVAL is null");
            return (Criteria) this;
        }

        public Criteria andFspcvalIsNotNull() {
            addCriterion("FSPCVAL is not null");
            return (Criteria) this;
        }

        public Criteria andFspcvalEqualTo(String value) {
            addCriterion("FSPCVAL =", value, "fspcval");
            return (Criteria) this;
        }

        public Criteria andFspcvalNotEqualTo(String value) {
            addCriterion("FSPCVAL <>", value, "fspcval");
            return (Criteria) this;
        }

        public Criteria andFspcvalGreaterThan(String value) {
            addCriterion("FSPCVAL >", value, "fspcval");
            return (Criteria) this;
        }

        public Criteria andFspcvalGreaterThanOrEqualTo(String value) {
            addCriterion("FSPCVAL >=", value, "fspcval");
            return (Criteria) this;
        }

        public Criteria andFspcvalLessThan(String value) {
            addCriterion("FSPCVAL <", value, "fspcval");
            return (Criteria) this;
        }

        public Criteria andFspcvalLessThanOrEqualTo(String value) {
            addCriterion("FSPCVAL <=", value, "fspcval");
            return (Criteria) this;
        }

        public Criteria andFspcvalLike(String value) {
            addCriterion("FSPCVAL like", value, "fspcval");
            return (Criteria) this;
        }

        public Criteria andFspcvalNotLike(String value) {
            addCriterion("FSPCVAL not like", value, "fspcval");
            return (Criteria) this;
        }

        public Criteria andFspcvalIn(List<String> values) {
            addCriterion("FSPCVAL in", values, "fspcval");
            return (Criteria) this;
        }

        public Criteria andFspcvalNotIn(List<String> values) {
            addCriterion("FSPCVAL not in", values, "fspcval");
            return (Criteria) this;
        }

        public Criteria andFspcvalBetween(String value1, String value2) {
            addCriterion("FSPCVAL between", value1, value2, "fspcval");
            return (Criteria) this;
        }

        public Criteria andFspcvalNotBetween(String value1, String value2) {
            addCriterion("FSPCVAL not between", value1, value2, "fspcval");
            return (Criteria) this;
        }

        public Criteria andFspcdbcIsNull() {
            addCriterion("FSPCDBC is null");
            return (Criteria) this;
        }

        public Criteria andFspcdbcIsNotNull() {
            addCriterion("FSPCDBC is not null");
            return (Criteria) this;
        }

        public Criteria andFspcdbcEqualTo(String value) {
            addCriterion("FSPCDBC =", value, "fspcdbc");
            return (Criteria) this;
        }

        public Criteria andFspcdbcNotEqualTo(String value) {
            addCriterion("FSPCDBC <>", value, "fspcdbc");
            return (Criteria) this;
        }

        public Criteria andFspcdbcGreaterThan(String value) {
            addCriterion("FSPCDBC >", value, "fspcdbc");
            return (Criteria) this;
        }

        public Criteria andFspcdbcGreaterThanOrEqualTo(String value) {
            addCriterion("FSPCDBC >=", value, "fspcdbc");
            return (Criteria) this;
        }

        public Criteria andFspcdbcLessThan(String value) {
            addCriterion("FSPCDBC <", value, "fspcdbc");
            return (Criteria) this;
        }

        public Criteria andFspcdbcLessThanOrEqualTo(String value) {
            addCriterion("FSPCDBC <=", value, "fspcdbc");
            return (Criteria) this;
        }

        public Criteria andFspcdbcLike(String value) {
            addCriterion("FSPCDBC like", value, "fspcdbc");
            return (Criteria) this;
        }

        public Criteria andFspcdbcNotLike(String value) {
            addCriterion("FSPCDBC not like", value, "fspcdbc");
            return (Criteria) this;
        }

        public Criteria andFspcdbcIn(List<String> values) {
            addCriterion("FSPCDBC in", values, "fspcdbc");
            return (Criteria) this;
        }

        public Criteria andFspcdbcNotIn(List<String> values) {
            addCriterion("FSPCDBC not in", values, "fspcdbc");
            return (Criteria) this;
        }

        public Criteria andFspcdbcBetween(String value1, String value2) {
            addCriterion("FSPCDBC between", value1, value2, "fspcdbc");
            return (Criteria) this;
        }

        public Criteria andFspcdbcNotBetween(String value1, String value2) {
            addCriterion("FSPCDBC not between", value1, value2, "fspcdbc");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}